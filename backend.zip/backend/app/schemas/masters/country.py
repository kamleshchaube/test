from pydantic import BaseModel, Field
from typing import Optional, List, Union
from datetime import datetime
from .DefaultResponse import DefaultResponse


# ---------------- Base Schema ----------------
class CountryBase(BaseModel):
    country_name: str = Field(..., min_length=2, max_length=100)
    country_code: str = Field(..., min_length=2, max_length=10)
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False


# ---------------- Create & Update ----------------
class CountryCreate(CountryBase):
    pass

class CountryUpdate(CountryBase):
    country_name: Optional[str] = Field(None, min_length=2, max_length=100)
    country_code: Optional[str] = Field(None, min_length=2, max_length=10)


# ---------------- Output Schema ----------------
class CountryOut(BaseModel):
    id: int
    country_name: Optional[str] = None
    country_code: Optional[str] = None
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None

    class Config:
        orm_mode = True


# ---------------- Paginated List ----------------
class PaginatedCountries(BaseModel):
    countries: List[CountryOut]
    total: int
    limit: int
    page: int

    class Config:
        orm_mode = True


# ---------------- Export Schema ----------------
class CountryExportOut(BaseModel):
    country_name: str
    country_code: str
    is_active: Optional[bool] = True
    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


# ---------------- API Response ----------------
class CountryResponse(DefaultResponse):
    data: Optional[Union[CountryOut, PaginatedCountries, List[CountryExportOut]]] = None

    class Config:
        orm_mode = True