from pydantic import BaseModel, Field, validator
from typing import Optional, List, Union, Dict, Any
from datetime import datetime, date
from decimal import Decimal
from .DefaultResponse import DefaultResponse


# ---------------- Base Schema ----------------
class LeadBase(BaseModel):
    project_title: str = Field(..., min_length=3)
    lead_source_id: int
    lead_status_id: int
    
    # Company and Customer Details
    company_id: int
    end_customer_id: Optional[int] = None
    end_customer_region: Optional[str] = None
    
    # Business Details
    sub_business_type: Optional[str] = None
    products_services: Optional[List[Dict[str, Any]]] = None
    expected_revenue: Decimal = Field(..., gt=0)
    revenue_currency: Optional[str] = "INR"
    
    # Tender Details
    tender_type: Optional[str] = None
    tender_fee: Optional[Decimal] = None
    currency: Optional[str] = "INR"
    submission_type: Optional[str] = None
    tender_authority: Optional[str] = None
    tender_for: Optional[str] = None
    
    # EMD and BG Details
    emd_required: Optional[bool] = False
    emd_amount: Optional[Decimal] = None
    emd_currency: Optional[str] = "INR"
    bg_required: Optional[bool] = False
    bg_amount: Optional[Decimal] = None
    bg_currency: Optional[str] = "INR"
    
    # Additional Details
    important_dates: Optional[List[Dict[str, Any]]] = None
    clauses: Optional[List[Dict[str, Any]]] = None
    competitors: Optional[List[Dict[str, Any]]] = None
    documents: Optional[List[Dict[str, Any]]] = None
    contacts: Optional[List[Dict[str, Any]]] = None
    
    # Lead Management
    priority: Optional[str] = "Medium"
    qualification_notes: Optional[str] = None
    lead_score: Optional[int] = 0
    convert_to_opportunity_date: Optional[date] = None
    
    # Assignment
    sales_person_id: Optional[int] = None
    
    # Conversion Workflow
    ready_for_conversion: Optional[bool] = False
    
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False

    @validator('priority')
    def validate_priority(cls, v):
        if v and v not in ['High', 'Medium', 'Low']:
            raise ValueError('Priority must be High, Medium, or Low')
        return v


# ---------------- Create & Update ----------------
class LeadCreate(LeadBase):
    pass

class LeadUpdate(LeadBase):
    project_title: Optional[str] = None
    lead_source_id: Optional[int] = None
    lead_status_id: Optional[int] = None
    company_id: Optional[int] = None
    expected_revenue: Optional[Decimal] = None


# ---------------- Output Schema ----------------
class LeadOut(BaseModel):
    id: int
    project_title: Optional[str] = None
    lead_source_id: Optional[int] = None
    lead_status_id: Optional[int] = None
    
    # Company and Customer Details
    company_id: Optional[int] = None
    end_customer_id: Optional[int] = None
    end_customer_region: Optional[str] = None
    
    # Business Details
    sub_business_type: Optional[str] = None
    products_services: Optional[List[Dict[str, Any]]] = None
    expected_revenue: Optional[Decimal] = None
    revenue_currency: Optional[str] = None
    
    # Tender Details
    tender_type: Optional[str] = None
    tender_fee: Optional[Decimal] = None
    currency: Optional[str] = None
    submission_type: Optional[str] = None
    tender_authority: Optional[str] = None
    tender_for: Optional[str] = None
    
    # EMD and BG Details
    emd_required: Optional[bool] = None
    emd_amount: Optional[Decimal] = None
    emd_currency: Optional[str] = None
    bg_required: Optional[bool] = None
    bg_amount: Optional[Decimal] = None
    bg_currency: Optional[str] = None
    
    # Additional Details
    important_dates: Optional[List[Dict[str, Any]]] = None
    clauses: Optional[List[Dict[str, Any]]] = None
    competitors: Optional[List[Dict[str, Any]]] = None
    documents: Optional[List[Dict[str, Any]]] = None
    contacts: Optional[List[Dict[str, Any]]] = None
    
    # Lead Management
    priority: Optional[str] = None
    qualification_notes: Optional[str] = None
    lead_score: Optional[int] = None
    convert_to_opportunity_date: Optional[date] = None
    
    # Assignment
    sales_person_id: Optional[int] = None
    
    # Conversion Workflow
    ready_for_conversion: Optional[bool] = None
    conversion_requested: Optional[bool] = None
    conversion_request_date: Optional[datetime] = None
    conversion_requested_by: Optional[int] = None
    
    # Review and Approval
    reviewed: Optional[bool] = None
    review_status: Optional[str] = None
    reviewed_by: Optional[int] = None
    review_date: Optional[datetime] = None
    review_comments: Optional[str] = None
    
    # Conversion Tracking
    converted: Optional[bool] = None
    converted_to_opportunity_id: Optional[str] = None
    conversion_date: Optional[datetime] = None
    conversion_notes: Optional[str] = None
    
    # Computed properties
    company_name: Optional[str] = None
    end_customer_name: Optional[str] = None
    creator_name: Optional[str] = None
    sales_person_name: Optional[str] = None
    conversion_requester_name: Optional[str] = None
    reviewer_name: Optional[str] = None
    can_request_conversion: Optional[bool] = None
    can_convert_to_opportunity: Optional[bool] = None
    needs_admin_review: Optional[bool] = None
    
    # Standard fields
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None

    class Config:
        orm_mode = True


# ---------------- Paginated List ----------------
class PaginatedLeads(BaseModel):
    leads: List[LeadOut]
    total: int
    limit: int
    page: int

    class Config:
        orm_mode = True


# ---------------- Export Schema ----------------
class LeadExportOut(BaseModel):
    project_title: str
    expected_revenue: Optional[Decimal] = None
    revenue_currency: Optional[str] = None
    priority: Optional[str] = None
    company_name: Optional[str] = None
    creator_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


# ---------------- Special Schemas ----------------
class ConversionRequestSchema(BaseModel):
    notes: Optional[str] = None

class ReviewDecisionSchema(BaseModel):
    decision: str = Field(..., pattern="^(Approved|Rejected)$")
    comments: Optional[str] = None

class ConvertToOpportunitySchema(BaseModel):
    opportunity_name: Optional[str] = None
    notes: Optional[str] = None


# ---------------- API Response ----------------
class LeadResponse(DefaultResponse):
    data: Optional[Union[LeadOut, PaginatedLeads, List[LeadExportOut]]] = None

    class Config:
        orm_mode = True