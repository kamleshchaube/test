from pydantic import BaseModel, Field, validator
from typing import Optional, List, Union, Dict, Any
from datetime import datetime, date
from decimal import Decimal
from .DefaultResponse import DefaultResponse


# ---------------- Base Schema ----------------
class OpportunityBase(BaseModel):
    lead_id: Optional[int] = None
    company_id: int
    contact_id: int
    name: str = Field(..., min_length=3)
    stage_id: int
    amount: Optional[Decimal] = None
    scoring: Optional[int] = Field(0, ge=0, le=100)
    bom_id: Optional[int] = None
    costing: Optional[Decimal] = None
    status: Optional[str] = "Open"
    justification: Optional[str] = None
    close_date: Optional[date] = None
    probability: Optional[int] = Field(10, ge=0, le=100)
    notes: Optional[str] = None
    
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False

    @validator('status')
    def validate_status(cls, v):
        if v and v not in ['Open', 'Won', 'Lost', 'Dropped']:
            raise ValueError('Status must be Open, Won, Lost, or Dropped')
        return v

    @validator('amount', 'costing')
    def validate_amounts(cls, v):
        if v is not None and v < 0:
            raise ValueError('Amount and costing must be positive')
        return v


# ---------------- Create & Update ----------------
class OpportunityCreate(OpportunityBase):
    pass

class OpportunityUpdate(OpportunityBase):
    company_id: Optional[int] = None
    contact_id: Optional[int] = None
    name: Optional[str] = None
    stage_id: Optional[int] = None


# ---------------- Output Schema ----------------
class OpportunityOut(BaseModel):
    id: int
    pot_id: Optional[str] = None
    lead_id: Optional[int] = None
    company_id: Optional[int] = None
    contact_id: Optional[int] = None
    
    # Core fields
    name: Optional[str] = None
    stage_id: Optional[int] = None
    amount: Optional[Decimal] = None
    scoring: Optional[int] = None
    bom_id: Optional[int] = None
    costing: Optional[Decimal] = None
    status: Optional[str] = None
    justification: Optional[str] = None
    close_date: Optional[date] = None
    probability: Optional[int] = None
    notes: Optional[str] = None
    
    # L1 - Qualification Stage Fields
    requirement_gathering_notes: Optional[str] = None
    go_no_go_status: Optional[str] = None
    qualification_completed_by: Optional[int] = None
    qualification_status: Optional[str] = None
    qualification_scorecard: Optional[Dict[str, Any]] = None
    
    # L2 - Need Analysis / Demo Stage Fields
    demo_completed: Optional[bool] = None
    demo_date: Optional[datetime] = None
    demo_summary: Optional[str] = None
    presentation_materials: Optional[List[Dict[str, Any]]] = None
    qualification_meeting_completed: Optional[bool] = None
    qualification_meeting_date: Optional[datetime] = None
    qualification_meeting_notes: Optional[str] = None
    
    # L3 - Proposal / Bid Submission Stage Fields
    quotation_created: Optional[bool] = None
    quotation_status: Optional[str] = None
    quotation_file_path: Optional[str] = None
    quotation_version: Optional[int] = None
    proposal_prepared: Optional[bool] = None
    proposal_file_path: Optional[str] = None
    proposal_submitted: Optional[bool] = None
    proposal_submission_date: Optional[datetime] = None
    poc_completed: Optional[bool] = None
    poc_notes: Optional[str] = None
    solutions_team_approval_notes: Optional[str] = None
    
    # L4 - Negotiation Stage Fields
    customer_discussion_notes: Optional[str] = None
    proposal_updated: Optional[bool] = None
    updated_proposal_file_path: Optional[str] = None
    updated_proposal_submitted: Optional[bool] = None
    negotiated_quotation_file_path: Optional[str] = None
    negotiation_rounds: Optional[int] = None
    commercial_approval_required: Optional[bool] = None
    commercial_approval_status: Optional[str] = None
    
    # L5 - Won Stage Fields
    kickoff_meeting_scheduled: Optional[bool] = None
    kickoff_meeting_date: Optional[datetime] = None
    loi_received: Optional[bool] = None
    loi_file_path: Optional[str] = None
    order_verified: Optional[bool] = None
    handoff_to_delivery: Optional[bool] = None
    delivery_team_assigned: Optional[int] = None
    
    # Lost/Dropped Stage Fields
    lost_reason: Optional[str] = None
    competitor_name: Optional[str] = None
    follow_up_date: Optional[date] = None
    drop_reason: Optional[str] = None
    reactivate_date: Optional[date] = None
    
    # Computed properties
    company_name: Optional[str] = None
    lead_name: Optional[str] = None
    contact_name: Optional[str] = None
    creator_name: Optional[str] = None
    updater_name: Optional[str] = None
    stage_percentage: Optional[int] = None
    stage_display_name: Optional[str] = None
    
    # Standard fields
    is_active: Optional[bool] = True
    is_deleted: Optional[bool] = False
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None

    class Config:
        orm_mode = True


# ---------------- Paginated List ----------------
class PaginatedOpportunities(BaseModel):
    opportunities: List[OpportunityOut]
    total: int
    limit: int
    page: int

    class Config:
        orm_mode = True


# ---------------- Export Schema ----------------
class OpportunityExportOut(BaseModel):
    pot_id: str
    name: str
    amount: Optional[Decimal] = None
    stage_display_name: Optional[str] = None
    status: Optional[str] = None
    company_name: Optional[str] = None
    creator_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


# ---------------- Special Schemas ----------------
class OpportunityStageUpdate(BaseModel):
    stage_id: int
    notes: Optional[str] = None
    stage_specific_data: Optional[Dict[str, Any]] = None

class OpportunityCloseRequest(BaseModel):
    status: str = Field(..., pattern="^(Won|Lost|Dropped)$")
    close_date: date
    notes: Optional[str] = None
    lost_reason: Optional[str] = None
    competitor_name: Optional[str] = None
    drop_reason: Optional[str] = None

class QualificationTaskUpdate(BaseModel):
    requirement_gathering_notes: Optional[str] = None
    go_no_go_status: Optional[str] = None
    qualification_status: Optional[str] = None
    qualification_scorecard: Optional[Dict[str, Any]] = None

class DemoTaskUpdate(BaseModel):
    demo_completed: Optional[bool] = None
    demo_date: Optional[datetime] = None
    demo_summary: Optional[str] = None
    presentation_materials: Optional[List[Dict[str, Any]]] = None
    qualification_meeting_completed: Optional[bool] = None
    qualification_meeting_date: Optional[datetime] = None
    qualification_meeting_notes: Optional[str] = None

class ProposalTaskUpdate(BaseModel):
    quotation_created: Optional[bool] = None
    quotation_status: Optional[str] = None
    quotation_file_path: Optional[str] = None
    quotation_version: Optional[int] = None
    proposal_prepared: Optional[bool] = None
    proposal_file_path: Optional[str] = None
    proposal_submitted: Optional[bool] = None
    proposal_submission_date: Optional[datetime] = None
    poc_completed: Optional[bool] = None
    poc_notes: Optional[str] = None
    solutions_team_approval_notes: Optional[str] = None

class NegotiationTaskUpdate(BaseModel):
    customer_discussion_notes: Optional[str] = None
    proposal_updated: Optional[bool] = None
    updated_proposal_file_path: Optional[str] = None
    updated_proposal_submitted: Optional[bool] = None
    negotiated_quotation_file_path: Optional[str] = None
    negotiation_rounds: Optional[int] = None
    commercial_approval_required: Optional[bool] = None
    commercial_approval_status: Optional[str] = None

class WonTaskUpdate(BaseModel):
    kickoff_meeting_scheduled: Optional[bool] = None
    kickoff_meeting_date: Optional[datetime] = None
    loi_received: Optional[bool] = None
    loi_file_path: Optional[str] = None
    order_verified: Optional[bool] = None
    handoff_to_delivery: Optional[bool] = None
    delivery_team_assigned: Optional[int] = None


# ---------------- API Response ----------------
class OpportunityResponse(DefaultResponse):
    data: Optional[Union[OpportunityOut, PaginatedOpportunities, List[OpportunityExportOut]]] = None

    class Config:
        orm_mode = True