from pydantic import BaseModel, Field, validator
from typing import Optional, List, Union
from datetime import datetime
from app.schemas.masters.DefaultResponse import DefaultResponse


# ---------------- Base Schema ----------------
class CompanyBase(BaseModel):
    company_code: str = Field(..., min_length=1, max_length=100)
    company_name: str = Field(..., min_length=3, max_length=255)
    company_type_id: Optional[int] = None
    gst_no: str = Field(..., min_length=15, max_length=15)
    pan_no: str = Field(..., min_length=10, max_length=10)
    account_type_id: Optional[int] = None
    account_region_id: Optional[int] = None
    business_type_id: Optional[int] = None
    industry_segment_id: Optional[int] = None
    sub_industry_segment_id: Optional[int] = None
    partner_type_id: Optional[int] = None
    head_of_company_id: Optional[int] = None
    website: Optional[str] = Field(None, max_length=255)
    is_active: Optional[bool] = True
    is_child: Optional[bool] = False
    remarks: Optional[str] = None
    is_deleted: Optional[bool] = False

    @validator('gst_no')
    def validate_gst(cls, v):
        if v and len(v) != 15:
            raise ValueError('GST number must be exactly 15 characters')
        return v

    @validator('pan_no')
    def validate_pan(cls, v):
        if v and len(v) != 10:
            raise ValueError('PAN number must be exactly 10 characters')
        return v


# ---------------- Create & Update ----------------
class CompanyCreate(CompanyBase):
    pass

class CompanyUpdate(CompanyBase):
    company_code: Optional[str] = Field(None, min_length=1, max_length=100)
    company_name: Optional[str] = Field(None, min_length=3, max_length=255)
    gst_no: Optional[str] = Field(None, min_length=15, max_length=15)
    pan_no: Optional[str] = Field(None, min_length=10, max_length=10)


# ---------------- Output Schema ----------------
class CompanyOut(BaseModel):
    id: int
    company_code: Optional[str] = None
    company_name: Optional[str] = None
    company_type_id: Optional[int] = None
    gst_no: Optional[str] = None
    pan_no: Optional[str] = None
    account_type_id: Optional[int] = None
    account_region_id: Optional[int] = None
    business_type_id: Optional[int] = None
    industry_segment_id: Optional[int] = None
    sub_industry_segment_id: Optional[int] = None
    partner_type_id: Optional[int] = None
    head_of_company_id: Optional[int] = None
    website: Optional[str] = None
    is_active: Optional[bool] = True
    is_child: Optional[bool] = False
    remarks: Optional[str] = None
    is_deleted: Optional[bool] = False
    
    # Computed fields
    creator_name: Optional[str] = None
    updater_name: Optional[str] = None
    company_type_name: Optional[str] = None
    industry_name: Optional[str] = None
    
    # Standard fields
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None

    class Config:
        orm_mode = True


# ---------------- Paginated List ----------------
class PaginatedCompanies(BaseModel):
    companies: List[CompanyOut]
    total: int
    limit: int
    page: int

    class Config:
        orm_mode = True


# ---------------- Export Schema ----------------
class CompanyExportOut(BaseModel):
    company_code: str
    company_name: str
    gst_no: str
    pan_no: str
    website: Optional[str] = None
    is_active: Optional[bool] = True
    company_type_name: Optional[str] = None
    industry_name: Optional[str] = None
    created_by_name: Optional[str] = None
    updated_by_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


# ---------------- Detailed Schema with Related Data ----------------
class CompanyDetailOut(CompanyOut):
    addresses: Optional[List[dict]] = []
    contacts: Optional[List[dict]] = []
    documents: Optional[List[dict]] = []
    financials: Optional[List[dict]] = []

    class Config:
        orm_mode = True


# ---------------- API Response ----------------
class CompanyResponse(DefaultResponse):
    data: Optional[Union[CompanyOut, CompanyDetailOut, PaginatedCompanies, List[CompanyExportOut]]] = None

    class Config:
        orm_mode = True