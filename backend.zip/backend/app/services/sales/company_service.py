from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func, and_
from fastapi import HTTPException, status
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.models.sales.company import Company
from app.models.masters.company_type import CompanyType
from app.models.masters.account_type import AccountType
from app.models.masters.business_type import BusinessType
from app.models.masters.industry_segment import IndustrySegment
from app.models.masters.sub_industry_segment import SubIndustrySegment
from app.models.masters.partner_type import PartnerType
from app.models.masters.head_of_company import HeadOfCompany
from app.schemas.sales.company import CompanyCreate, CompanyUpdate

def map_company(company: Company) -> Optional[Dict[str, Any]]:
    if not company:
        return None
    return {
        "id": company.id,
        "company_code": company.company_code,
        "company_name": company.company_name,
        "company_type_id": company.company_type_id,
        "gst_no": company.gst_no,
        "pan_no": company.pan_no,
        "account_type_id": company.account_type_id,
        "account_region_id": company.account_region_id,
        "business_type_id": company.business_type_id,
        "industry_segment_id": company.industry_segment_id,
        "sub_industry_segment_id": company.sub_industry_segment_id,
        "partner_type_id": company.partner_type_id,
        "head_of_company_id": company.head_of_company_id,
        "website": company.website,
        "is_active": company.is_active,
        "is_child": company.is_child,
        "remarks": company.remarks,
        "is_deleted": company.is_deleted,
        
        # Computed fields
        "creator_name": company.creator_name,
        "updater_name": company.updater_name,
        "company_type_name": company.company_type_name,
        "industry_name": company.industry_name,
        
        # Standard fields
        "created_by": company.created_by,
        "updated_by": company.updated_by,
        "created_at": company.created_at,
        "updated_at": company.updated_at,
        "created_by_name": company.created_user.full_name if company.created_user else None,
        "updated_by_name": company.updated_user.full_name if company.updated_user else None
    }

def validate_foreign_keys(db: Session, company_data: Dict[str, Any]):
    """Validate foreign key references"""
    
    # Validate company_type_id
    if 'company_type_id' in company_data and company_data['company_type_id']:
        company_type = db.query(CompanyType).filter(
            CompanyType.id == company_data['company_type_id'],
            CompanyType.is_active == True,
            CompanyType.is_deleted == False
        ).first()
        if not company_type:
            raise HTTPException(
                status_code=400,
                detail=f"Company Type with ID {company_data['company_type_id']} not found or inactive"
            )
    
    # Validate account_type_id
    if 'account_type_id' in company_data and company_data['account_type_id']:
        account_type = db.query(AccountType).filter(
            AccountType.id == company_data['account_type_id'],
            AccountType.is_active == True,
            AccountType.is_deleted == False
        ).first()
        if not account_type:
            raise HTTPException(
                status_code=400,
                detail=f"Account Type with ID {company_data['account_type_id']} not found or inactive"
            )

def create_company(db: Session, company_data: CompanyCreate, login_id: int):
    try:
        # Convert to dict for validation
        data_dict = company_data.dict(exclude_unset=True)
        
        # Validate foreign keys
        validate_foreign_keys(db, data_dict)
        
        # Check for duplicate company code or GST/PAN
        existing_code = db.query(Company).filter(
            Company.company_code == company_data.company_code,
            Company.is_deleted == False
        ).first()
        if existing_code:
            raise HTTPException(
                status_code=400,
                detail=f"Company with code '{company_data.company_code}' already exists."
            )
        
        existing_gst = db.query(Company).filter(
            Company.gst_no == company_data.gst_no,
            Company.is_deleted == False
        ).first()
        if existing_gst:
            raise HTTPException(
                status_code=400,
                detail=f"Company with GST number '{company_data.gst_no}' already exists."
            )
        
        existing_pan = db.query(Company).filter(
            Company.pan_no == company_data.pan_no,
            Company.is_deleted == False
        ).first()
        if existing_pan:
            raise HTTPException(
                status_code=400,
                detail=f"Company with PAN number '{company_data.pan_no}' already exists."
            )
        
        # Create company
        db_company = Company(
            **data_dict,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_company)
        db.commit()
        db.refresh(db_company)

        return map_company(db_company)

    except HTTPException:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Company")
    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Company")

def get_companies(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None,
                  company_type_id: Optional[int] = None, industry_id: Optional[int] = None,
                  is_active: Optional[bool] = None):
    try:
        query = db.query(Company).filter(Company.is_deleted == False)
        
        if search:
            query = query.filter(or_(
                Company.company_name.ilike(f"%{search}%"),
                Company.company_code.ilike(f"%{search}%"),
                Company.gst_no.ilike(f"%{search}%"),
                Company.pan_no.ilike(f"%{search}%")
            ))
        
        if company_type_id:
            query = query.filter(Company.company_type_id == company_type_id)
            
        if industry_id:
            query = query.filter(Company.industry_segment_id == industry_id)
            
        if is_active is not None:
            query = query.filter(Company.is_active == is_active)
        
        total = query.count()
        records = query.order_by(Company.id.desc()).offset(skip).limit(limit).all()
        
        return {
            "companies": [map_company(company) for company in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch companies")

def get_company_by_id(db: Session, company_id: int, include_related: bool = False):
    try:
        record = db.query(Company).filter(
            Company.id == company_id,
            Company.is_deleted == False
        ).first()
        
        if not record:
            return None
            
        result = map_company(record)
        
        if include_related:
            # Add related data
            result["addresses"] = [
                {
                    "id": addr.id,
                    "address_type": addr.address_type_name,
                    "full_address": addr.full_address,
                    "country": addr.country.country_name if addr.country else None,
                    "state": addr.state.state_name if addr.state else None,
                    "city": addr.city.city_name if addr.city else None,
                    "zipcode": addr.zipcode
                }
                for addr in record.addresses if not addr.is_deleted
            ]
            
            result["contacts"] = [
                {
                    "id": contact.id,
                    "full_name": contact.full_name,
                    "email": contact.email,
                    "phone": contact.phone,
                    "mobile": contact.mobile,
                    "designation": contact.designation_name,
                    "is_primary": contact.is_primary
                }
                for contact in record.contacts if not contact.is_deleted
            ]
            
            result["documents"] = [
                {
                    "id": doc.id,
                    "document_type": doc.document_type_name,
                    "file_path": doc.file_path,
                    "description": doc.description
                }
                for doc in record.documents if not doc.is_deleted
            ]
            
            result["financials"] = [
                {
                    "id": fin.id,
                    "year": fin.year,
                    "revenue": fin.revenue,
                    "profit": fin.profit,
                    "currency": fin.currency_code,
                    "type": fin.type.value
                }
                for fin in record.financials if not fin.is_deleted
            ]
            
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch company")

def update_company(db: Session, company_id: int, data: CompanyUpdate, login_id: int):
    try:
        db_obj = db.query(Company).filter(Company.id == company_id, Company.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Convert to dict and validate foreign keys
        update_data = data.dict(exclude_unset=True)
        validate_foreign_keys(db, update_data)
        
        # Check for duplicates when updating unique fields
        if 'company_code' in update_data and update_data['company_code'] != db_obj.company_code:
            existing = db.query(Company).filter(
                Company.company_code == update_data['company_code'],
                Company.is_deleted == False,
                Company.id != company_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Company code '{update_data['company_code']}' already exists."
                )
        
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_company(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update company")

def delete_company(db: Session, company_id: int, login_id: int):
    try:
        db_obj = db.query(Company).filter(Company.id == company_id, Company.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_company(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete company")

def get_company_stats(db: Session):
    try:
        stats = {}
        
        # Total companies
        stats['total_companies'] = db.query(Company).filter(Company.is_deleted == False).count()
        
        # Active companies
        stats['active_companies'] = db.query(Company).filter(
            Company.is_deleted == False,
            Company.is_active == True
        ).count()
        
        # Companies by type
        type_counts = db.query(CompanyType.type_name, func.count(Company.id)).join(
            Company, Company.company_type_id == CompanyType.id
        ).filter(Company.is_deleted == False).group_by(CompanyType.type_name).all()
        
        stats['by_type'] = {type_name: count for type_name, count in type_counts}
        
        # Companies by industry
        industry_counts = db.query(IndustrySegment.industry_name, func.count(Company.id)).join(
            Company, Company.industry_segment_id == IndustrySegment.id
        ).filter(Company.is_deleted == False).group_by(IndustrySegment.industry_name).all()
        
        stats['by_industry'] = {industry: count for industry, count in industry_counts}
        
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch company statistics")