from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func, and_
from fastapi import HTTPException, status
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.models.crm.lead import Lead
from app.models.crm.lead_source import LeadSource
from app.models.crm.lead_status import LeadStatus
from app.schemas.crm.lead import LeadCreate, LeadUpdate

def map_lead(lead: Lead) -> Optional[Dict[str, Any]]:
    if not lead:
        return None
    return {
        "id": lead.id,
        "project_title": lead.project_title,
        "lead_source_id": lead.lead_source_id,
        "lead_status_id": lead.lead_status_id,
        
        # Company and Customer Details
        "company_id": lead.company_id,
        "end_customer_id": lead.end_customer_id,
        "end_customer_region": lead.end_customer_region,
        
        # Business Details
        "sub_business_type": lead.sub_business_type,
        "products_services": lead.products_services,
        "expected_revenue": lead.expected_revenue,
        "revenue_currency": lead.revenue_currency,
        
        # Tender Details
        "tender_type": lead.tender_type,
        "tender_fee": lead.tender_fee,
        "currency": lead.currency,
        "submission_type": lead.submission_type,
        "tender_authority": lead.tender_authority,
        "tender_for": lead.tender_for,
        
        # EMD and BG Details
        "emd_required": lead.emd_required,
        "emd_amount": lead.emd_amount,
        "emd_currency": lead.emd_currency,
        "bg_required": lead.bg_required,
        "bg_amount": lead.bg_amount,
        "bg_currency": lead.bg_currency,
        
        # Additional Details
        "important_dates": lead.important_dates,
        "clauses": lead.clauses,
        "competitors": lead.competitors,
        "documents": lead.documents,
        "contacts": lead.contacts,
        
        # Lead Management
        "priority": lead.priority,
        "qualification_notes": lead.qualification_notes,
        "lead_score": lead.lead_score,
        "convert_to_opportunity_date": lead.convert_to_opportunity_date,
        
        # Assignment
        "sales_person_id": lead.sales_person_id,
        
        # Conversion Workflow
        "ready_for_conversion": lead.ready_for_conversion,
        "conversion_requested": lead.conversion_requested,
        "conversion_request_date": lead.conversion_request_date,
        "conversion_requested_by": lead.conversion_requested_by,
        
        # Review and Approval
        "reviewed": lead.reviewed,
        "review_status": lead.review_status,
        "reviewed_by": lead.reviewed_by,
        "review_date": lead.review_date,
        "review_comments": lead.review_comments,
        
        # Conversion Tracking
        "converted": lead.converted,
        "converted_to_opportunity_id": lead.converted_to_opportunity_id,
        "conversion_date": lead.conversion_date,
        "conversion_notes": lead.conversion_notes,
        
        # Computed properties
        "company_name": lead.company_name,
        "end_customer_name": lead.end_customer_name,
        "creator_name": lead.creator_name,
        "sales_person_name": lead.sales_person_name,
        "conversion_requester_name": lead.conversion_requester_name,
        "reviewer_name": lead.reviewer_name,
        "can_request_conversion": lead.can_request_conversion,
        "can_convert_to_opportunity": lead.can_convert_to_opportunity,
        "needs_admin_review": lead.needs_admin_review,
        
        # Standard fields
        "is_active": lead.is_active,
        "is_deleted": lead.is_deleted,
        "created_by": lead.created_by,
        "updated_by": lead.updated_by,
        "created_at": lead.created_at,
        "updated_at": lead.updated_at,
        "created_by_name": lead.created_user.full_name if lead.created_user else None,
        "updated_by_name": lead.updated_user.full_name if lead.updated_user else None
    }

def validate_foreign_keys(db: Session, lead_data: Dict[str, Any]):
    """Validate foreign key references"""
    # Validate lead_source_id
    if 'lead_source_id' in lead_data:
        lead_source = db.query(LeadSource).filter(
            LeadSource.id == lead_data['lead_source_id'],
            LeadSource.is_active == True,
            LeadSource.is_deleted == False
        ).first()
        if not lead_source:
            raise HTTPException(
                status_code=400,
                detail=f"Lead Source with ID {lead_data['lead_source_id']} not found or inactive"
            )
    
    # Validate lead_status_id
    if 'lead_status_id' in lead_data:
        lead_status = db.query(LeadStatus).filter(
            LeadStatus.id == lead_data['lead_status_id'],
            LeadStatus.is_active == True,
            LeadStatus.is_deleted == False
        ).first()
        if not lead_status:
            raise HTTPException(
                status_code=400,
                detail=f"Lead Status with ID {lead_data['lead_status_id']} not found or inactive"
            )

def create_lead(db: Session, lead_data: LeadCreate, login_id: int):
    try:
        # Convert to dict for validation
        data_dict = lead_data.dict(exclude_unset=True)
        
        # Validate foreign keys
        validate_foreign_keys(db, data_dict)
        
        # Create lead
        db_lead = Lead(
            **data_dict,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_lead)
        db.commit()
        db.refresh(db_lead)

        return map_lead(db_lead)

    except HTTPException:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Lead")
    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Lead")

def get_leads(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None, 
              status_filter: Optional[str] = None, company_id: Optional[int] = None, 
              review_status: Optional[str] = None):
    try:
        query = db.query(Lead).filter(Lead.is_deleted == False)
        
        if search:
            query = query.filter(or_(
                Lead.project_title.ilike(f"%{search}%"),
                Lead.tender_authority.ilike(f"%{search}%"),
                Lead.qualification_notes.ilike(f"%{search}%")
            ))
        
        if status_filter:
            query = query.join(LeadStatus).filter(LeadStatus.name == status_filter)
        
        if company_id:
            query = query.filter(Lead.company_id == company_id)
            
        if review_status:
            query = query.filter(Lead.review_status == review_status)
        
        total = query.count()
        records = query.order_by(Lead.id.desc()).offset(skip).limit(limit).all()
        
        return {
            "leads": [map_lead(lead) for lead in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch leads")

def get_lead_by_id(db: Session, lead_id: int):
    try:
        record = db.query(Lead).filter(
            Lead.id == lead_id,
            Lead.is_deleted == False
        ).first()
        return map_lead(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead")

def update_lead(db: Session, lead_id: int, data: LeadUpdate, login_id: int):
    try:
        db_obj = db.query(Lead).filter(Lead.id == lead_id, Lead.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Convert to dict and validate foreign keys
        update_data = data.dict(exclude_unset=True)
        validate_foreign_keys(db, update_data)
        
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update lead")

def delete_lead(db: Session, lead_id: int, login_id: int):
    try:
        db_obj = db.query(Lead).filter(Lead.id == lead_id, Lead.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete lead")

# Conversion workflow functions
def request_conversion(db: Session, lead_id: int, user_id: int, notes: Optional[str] = None):
    try:
        lead = db.query(Lead).filter(Lead.id == lead_id, Lead.is_deleted == False).first()
        if not lead:
            return None
        
        if not lead.can_request_conversion:
            raise ValueError("Lead cannot request conversion at this time")
        
        lead.conversion_requested = True
        lead.conversion_request_date = datetime.utcnow()
        lead.conversion_requested_by = user_id
        lead.review_status = "Pending"
        if notes:
            lead.qualification_notes = notes
        lead.updated_by = user_id
        
        db.commit()
        db.refresh(lead)
        return map_lead(lead)
    except ValueError:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to request conversion")

def review_conversion_request(db: Session, lead_id: int, user_id: int, decision: str, comments: Optional[str] = None):
    try:
        lead = db.query(Lead).filter(Lead.id == lead_id, Lead.is_deleted == False).first()
        if not lead:
            return None
        
        if not lead.conversion_requested:
            raise ValueError("No conversion request found for this lead")
        
        lead.reviewed = True
        lead.review_status = decision
        lead.reviewed_by = user_id
        lead.review_date = datetime.utcnow()
        lead.review_comments = comments
        lead.updated_by = user_id
        
        db.commit()
        db.refresh(lead)
        return map_lead(lead)
    except ValueError:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to review conversion request")

def mark_as_converted(db: Session, lead_id: int, opportunity_id: int, user_id: int, notes: Optional[str] = None):
    try:
        lead = db.query(Lead).filter(Lead.id == lead_id, Lead.is_deleted == False).first()
        if not lead:
            return None
        
        # Update lead status to converted
        converted_status = db.query(LeadStatus).filter(LeadStatus.name == "Converted").first()
        if converted_status:
            lead.lead_status_id = converted_status.id
        
        lead.converted = True
        lead.converted_to_opportunity_id = f"POT-{opportunity_id}"
        lead.conversion_date = datetime.utcnow()
        lead.conversion_notes = notes
        lead.updated_by = user_id
        
        db.commit()
        db.refresh(lead)
        return map_lead(lead)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to mark lead as converted")

def get_leads_pending_review(db: Session):
    try:
        records = db.query(Lead).filter(
            Lead.is_deleted == False,
            Lead.conversion_requested == True,
            Lead.reviewed == False
        ).all()
        return [map_lead(lead) for lead in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch leads pending review")

def get_lead_stats(db: Session):
    try:
        stats = {}
        
        # Total leads
        stats['total_leads'] = db.query(Lead).filter(Lead.is_deleted == False).count()
        
        # Leads by status
        status_counts = db.query(LeadStatus.name, func.count(Lead.id)).join(
            Lead, Lead.lead_status_id == LeadStatus.id
        ).filter(Lead.is_deleted == False).group_by(LeadStatus.name).all()
        
        stats['by_status'] = {status: count for status, count in status_counts}
        
        # Conversion stats
        stats['conversion_requested'] = db.query(Lead).filter(
            Lead.is_deleted == False,
            Lead.conversion_requested == True
        ).count()
        
        stats['converted'] = db.query(Lead).filter(
            Lead.is_deleted == False,
            Lead.converted == True
        ).count()
        
        stats['pending_review'] = db.query(Lead).filter(
            Lead.is_deleted == False,
            Lead.conversion_requested == True,
            Lead.reviewed == False
        ).count()
        
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead statistics")