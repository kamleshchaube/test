from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.crm.lead_source import LeadSource
from app.schemas.crm.lead_source import LeadSourceCreate, LeadSourceUpdate

def map_lead_source(ls: LeadSource) -> Optional[Dict[str, Any]]:
    if not ls:
        return None
    return {
        "id": ls.id,
        "name": ls.name,
        "description": ls.description,
        "is_active": ls.is_active,
        "is_deleted": ls.is_deleted,
        "created_by": ls.created_by,
        "updated_by": ls.updated_by,
        "created_at": ls.created_at,
        "updated_at": ls.updated_at,
        "created_by_name": ls.created_user.full_name if ls.created_user else None,
        "updated_by_name": ls.updated_user.full_name if ls.updated_user else None
    }

def create_lead_source(db: Session, ls_data: LeadSourceCreate, login_id: int):
    try:
        # Duplicate check (case-insensitive, not deleted)
        existing_ls = db.query(LeadSource).filter(
            func.lower(LeadSource.name) == ls_data.name.lower(),
            LeadSource.is_deleted == False
        ).first()

        if existing_ls:
            raise HTTPException(
                status_code=400,
                detail=f"Lead Source '{ls_data.name}' already exists."
            )

        # Save exactly as entered (strip only spaces)
        db_ls = LeadSource(
            name=ls_data.name.strip(),
            description=ls_data.description,
            is_active=ls_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_ls)
        db.commit()
        db.refresh(db_ls)

        return map_lead_source(db_ls)

    except HTTPException:
        raise

    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Lead Source")

    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Lead Source")

def get_lead_sources(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(LeadSource).filter(
            LeadSource.is_deleted == False
        )
        if search:
            query = query.filter(or_(
                LeadSource.name.ilike(f"%{search}%"),
                LeadSource.description.ilike(f"%{search}%")
            ))
        total = query.count()
        records = query.order_by(LeadSource.id.asc()).offset(skip).limit(limit).all()
        return {
            "lead_sources": [map_lead_source(ls) for ls in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead sources")

def get_lead_source_by_id(db: Session, ls_id: int):
    try:
        record = db.query(LeadSource).filter(
            LeadSource.id == ls_id,
            LeadSource.is_deleted == False
        ).first()
        return map_lead_source(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead source")

def update_lead_source(db: Session, ls_id: int, data: LeadSourceUpdate, login_id: int):
    try:
        db_obj = db.query(LeadSource).filter(LeadSource.id == ls_id, LeadSource.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating name
        if hasattr(data, 'name') and data.name and data.name.lower() != db_obj.name.lower():
            existing = db.query(LeadSource).filter(
                func.lower(LeadSource.name) == data.name.lower(),
                LeadSource.is_deleted == False,
                LeadSource.id != ls_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Lead Source '{data.name}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead_source(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update lead source")

def delete_lead_source(db: Session, ls_id: int, login_id: int):
    try:
        db_obj = db.query(LeadSource).filter(LeadSource.id == ls_id, LeadSource.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead_source(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete lead source")