from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func, and_
from fastapi import HTTPException, status
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.models.crm.opportunity import Opportunity
from app.models.crm.opportunity_stage import OpportunityStage
from app.schemas.crm.opportunity import OpportunityCreate, OpportunityUpdate

def map_opportunity(opp: Opportunity) -> Optional[Dict[str, Any]]:
    if not opp:
        return None
    return {
        "id": opp.id,
        "pot_id": opp.pot_id,
        "lead_id": opp.lead_id,
        "company_id": opp.company_id,
        "contact_id": opp.contact_id,
        
        # Core fields
        "name": opp.name,
        "stage_id": opp.stage_id,
        "amount": opp.amount,
        "scoring": opp.scoring,
        "bom_id": opp.bom_id,
        "costing": opp.costing,
        "status": opp.status,
        "justification": opp.justification,
        "close_date": opp.close_date,
        "probability": opp.probability,
        "notes": opp.notes,
        
        # L1 - Qualification Stage Fields
        "requirement_gathering_notes": opp.requirement_gathering_notes,
        "go_no_go_status": opp.go_no_go_status,
        "qualification_completed_by": opp.qualification_completed_by,
        "qualification_status": opp.qualification_status,
        "qualification_scorecard": opp.qualification_scorecard,
        
        # L2 - Need Analysis / Demo Stage Fields
        "demo_completed": opp.demo_completed,
        "demo_date": opp.demo_date,
        "demo_summary": opp.demo_summary,
        "presentation_materials": opp.presentation_materials,
        "qualification_meeting_completed": opp.qualification_meeting_completed,
        "qualification_meeting_date": opp.qualification_meeting_date,
        "qualification_meeting_notes": opp.qualification_meeting_notes,
        
        # L3 - Proposal / Bid Submission Stage Fields
        "quotation_created": opp.quotation_created,
        "quotation_status": opp.quotation_status,
        "quotation_file_path": opp.quotation_file_path,
        "quotation_version": opp.quotation_version,
        "proposal_prepared": opp.proposal_prepared,
        "proposal_file_path": opp.proposal_file_path,
        "proposal_submitted": opp.proposal_submitted,
        "proposal_submission_date": opp.proposal_submission_date,
        "poc_completed": opp.poc_completed,
        "poc_notes": opp.poc_notes,
        "solutions_team_approval_notes": opp.solutions_team_approval_notes,
        
        # L4 - Negotiation Stage Fields
        "customer_discussion_notes": opp.customer_discussion_notes,
        "proposal_updated": opp.proposal_updated,
        "updated_proposal_file_path": opp.updated_proposal_file_path,
        "updated_proposal_submitted": opp.updated_proposal_submitted,
        "negotiated_quotation_file_path": opp.negotiated_quotation_file_path,
        "negotiation_rounds": opp.negotiation_rounds,
        "commercial_approval_required": opp.commercial_approval_required,
        "commercial_approval_status": opp.commercial_approval_status,
        
        # L5 - Won Stage Fields
        "kickoff_meeting_scheduled": opp.kickoff_meeting_scheduled,
        "kickoff_meeting_date": opp.kickoff_meeting_date,
        "loi_received": opp.loi_received,
        "loi_file_path": opp.loi_file_path,
        "order_verified": opp.order_verified,
        "handoff_to_delivery": opp.handoff_to_delivery,
        "delivery_team_assigned": opp.delivery_team_assigned,
        
        # Lost/Dropped Stage Fields
        "lost_reason": opp.lost_reason,
        "competitor_name": opp.competitor_name,
        "follow_up_date": opp.follow_up_date,
        "drop_reason": opp.drop_reason,
        "reactivate_date": opp.reactivate_date,
        
        # Computed properties
        "company_name": opp.company_name,
        "lead_name": opp.lead_name,
        "contact_name": opp.contact_name,
        "creator_name": opp.creator_name,
        "updater_name": opp.updater_name,
        "stage_percentage": opp.stage_percentage,
        "stage_display_name": opp.stage_display_name,
        
        # Standard fields
        "is_active": opp.is_active,
        "is_deleted": opp.is_deleted,
        "created_by": opp.created_by,
        "updated_by": opp.updated_by,
        "created_at": opp.created_at,
        "updated_at": opp.updated_at,
        "created_by_name": opp.created_user.full_name if opp.created_user else None,
        "updated_by_name": opp.updated_user.full_name if opp.updated_user else None
    }

def validate_foreign_keys(db: Session, opp_data: Dict[str, Any]):
    """Validate foreign key references"""
    # Validate stage_id
    if 'stage_id' in opp_data:
        stage = db.query(OpportunityStage).filter(
            OpportunityStage.id == opp_data['stage_id'],
            OpportunityStage.is_active == True,
            OpportunityStage.is_deleted == False
        ).first()
        if not stage:
            raise HTTPException(
                status_code=400,
                detail=f"Opportunity Stage with ID {opp_data['stage_id']} not found or inactive"
            )

def create_opportunity(db: Session, opp_data: OpportunityCreate, login_id: int):
    try:
        # Convert to dict for validation
        data_dict = opp_data.dict(exclude_unset=True)
        
        # Validate foreign keys
        validate_foreign_keys(db, data_dict)
        
        # Create opportunity
        db_opp = Opportunity(
            **data_dict,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_opp)
        db.commit()
        db.refresh(db_opp)

        return map_opportunity(db_opp)

    except HTTPException:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Opportunity")
    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Opportunity")

def get_opportunities(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None,
                     stage_filter: Optional[str] = None, status_filter: Optional[str] = None):
    try:
        query = db.query(Opportunity).filter(Opportunity.is_deleted == False)
        
        if search:
            query = query.filter(or_(
                Opportunity.name.ilike(f"%{search}%"),
                Opportunity.pot_id.ilike(f"%{search}%"),
                Opportunity.notes.ilike(f"%{search}%")
            ))
        
        if stage_filter:
            query = query.join(OpportunityStage).filter(OpportunityStage.name == stage_filter)
        
        if status_filter:
            query = query.filter(Opportunity.status == status_filter)
        
        total = query.count()
        records = query.order_by(Opportunity.id.desc()).offset(skip).limit(limit).all()
        
        return {
            "opportunities": [map_opportunity(opp) for opp in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunities")

def get_opportunity_by_id(db: Session, opp_id: int):
    try:
        record = db.query(Opportunity).filter(
            Opportunity.id == opp_id,
            Opportunity.is_deleted == False
        ).first()
        return map_opportunity(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunity")

def get_opportunities_by_company(db: Session, company_id: int, skip: int = 0, limit: int = 10):
    try:
        query = db.query(Opportunity).filter(
            Opportunity.company_id == company_id,
            Opportunity.is_deleted == False
        )
        records = query.order_by(Opportunity.id.desc()).offset(skip).limit(limit).all()
        return [map_opportunity(opp) for opp in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunities by company")

def get_opportunities_by_lead(db: Session, lead_id: int, skip: int = 0, limit: int = 10):
    try:
        query = db.query(Opportunity).filter(
            Opportunity.lead_id == lead_id,
            Opportunity.is_deleted == False
        )
        records = query.order_by(Opportunity.id.desc()).offset(skip).limit(limit).all()
        return [map_opportunity(opp) for opp in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunities by lead")

def update_opportunity(db: Session, opp_id: int, data: OpportunityUpdate, login_id: int):
    try:
        db_obj = db.query(Opportunity).filter(Opportunity.id == opp_id, Opportunity.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Convert to dict and validate foreign keys
        update_data = data.dict(exclude_unset=True)
        validate_foreign_keys(db, update_data)
        
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_opportunity(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update opportunity")

def update_stage(db: Session, opp_id: int, stage_name: str, user_id: int, notes: Optional[str] = None, stage_data: Optional[Dict] = None):
    try:
        opp = db.query(Opportunity).filter(Opportunity.id == opp_id, Opportunity.is_deleted == False).first()
        if not opp:
            return None
        
        # Find the stage
        stage = db.query(OpportunityStage).filter(OpportunityStage.name == stage_name).first()
        if not stage:
            raise ValueError(f"Stage '{stage_name}' not found")
        
        opp.stage_id = stage.id
        opp.probability = stage.percentage
        if notes:
            opp.notes = notes
        
        # Update stage-specific fields if provided
        if stage_data:
            for field, value in stage_data.items():
                if hasattr(opp, field):
                    setattr(opp, field, value)
        
        opp.updated_by = user_id
        db.commit()
        db.refresh(opp)
        return map_opportunity(opp)
    except ValueError:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update opportunity stage")

def close_opportunity(db: Session, opp_id: int, status: str, close_date: str, user_id: int, 
                     notes: Optional[str] = None, lost_reason: Optional[str] = None,
                     competitor_name: Optional[str] = None, drop_reason: Optional[str] = None):
    try:
        opp = db.query(Opportunity).filter(Opportunity.id == opp_id, Opportunity.is_deleted == False).first()
        if not opp:
            return None
        
        opp.status = status
        opp.close_date = datetime.fromisoformat(close_date).date()
        
        if status == "Won":
            won_stage = db.query(OpportunityStage).filter(OpportunityStage.name == "L5_Won").first()
            if won_stage:
                opp.stage_id = won_stage.id
                opp.probability = 100
        elif status == "Lost":
            lost_stage = db.query(OpportunityStage).filter(OpportunityStage.name == "L6_Lost").first()
            if lost_stage:
                opp.stage_id = lost_stage.id
                opp.probability = 0
            opp.lost_reason = lost_reason
            opp.competitor_name = competitor_name
        elif status == "Dropped":
            dropped_stage = db.query(OpportunityStage).filter(OpportunityStage.name == "L7_Dropped").first()
            if dropped_stage:
                opp.stage_id = dropped_stage.id
                opp.probability = 0
            opp.drop_reason = drop_reason
        
        if notes:
            opp.notes = notes
        
        opp.updated_by = user_id
        db.commit()
        db.refresh(opp)
        return map_opportunity(opp)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to close opportunity")

def delete_opportunity(db: Session, opp_id: int, login_id: int):
    try:
        db_obj = db.query(Opportunity).filter(Opportunity.id == opp_id, Opportunity.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_opportunity(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete opportunity")

def get_opportunity_count(db: Session, stage_filter: Optional[str] = None, status_filter: Optional[str] = None, search: Optional[str] = None):
    try:
        query = db.query(Opportunity).filter(Opportunity.is_deleted == False)
        
        if search:
            query = query.filter(or_(
                Opportunity.name.ilike(f"%{search}%"),
                Opportunity.pot_id.ilike(f"%{search}%"),
                Opportunity.notes.ilike(f"%{search}%")
            ))
        
        if stage_filter:
            query = query.join(OpportunityStage).filter(OpportunityStage.name == stage_filter)
        
        if status_filter:
            query = query.filter(Opportunity.status == status_filter)
        
        return query.count()
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to get opportunity count")

def get_pipeline_summary(db: Session, user_id: Optional[int] = None):
    try:
        query = db.query(Opportunity).filter(Opportunity.is_deleted == False)
        
        if user_id:
            query = query.filter(Opportunity.created_by == user_id)
        
        # Summary by stage
        stage_summary = db.query(
            OpportunityStage.name,
            OpportunityStage.percentage,
            func.count(Opportunity.id).label('count'),
            func.sum(Opportunity.amount).label('total_amount')
        ).join(
            Opportunity, Opportunity.stage_id == OpportunityStage.id
        ).filter(
            Opportunity.is_deleted == False
        ).group_by(OpportunityStage.name, OpportunityStage.percentage).all()
        
        pipeline = []
        for stage_name, percentage, count, total_amount in stage_summary:
            pipeline.append({
                "stage": stage_name,
                "percentage": percentage,
                "count": count,
                "total_amount": float(total_amount or 0)
            })
        
        return {"pipeline": pipeline}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to get pipeline summary")

def get_opportunity_metrics(db: Session, user_id: Optional[int] = None):
    try:
        query = db.query(Opportunity).filter(Opportunity.is_deleted == False)
        
        if user_id:
            query = query.filter(Opportunity.created_by == user_id)
        
        metrics = {}
        
        # Total opportunities
        metrics['total_opportunities'] = query.count()
        
        # By status
        status_counts = query.with_entities(
            Opportunity.status,
            func.count(Opportunity.id)
        ).group_by(Opportunity.status).all()
        
        metrics['by_status'] = {status: count for status, count in status_counts}
        
        # Total value
        total_value = query.with_entities(func.sum(Opportunity.amount)).scalar()
        metrics['total_value'] = float(total_value or 0)
        
        return metrics
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to get opportunity metrics")