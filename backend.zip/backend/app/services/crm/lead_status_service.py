from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.crm.lead_status import LeadStatus
from app.schemas.crm.lead_status import LeadStatusCreate, LeadStatusUpdate

def map_lead_status(ls: LeadStatus) -> Optional[Dict[str, Any]]:
    if not ls:
        return None
    return {
        "id": ls.id,
        "name": ls.name,
        "description": ls.description,
        "is_active": ls.is_active,
        "is_deleted": ls.is_deleted,
        "created_by": ls.created_by,
        "updated_by": ls.updated_by,
        "created_at": ls.created_at,
        "updated_at": ls.updated_at,
        "created_by_name": ls.created_user.full_name if ls.created_user else None,
        "updated_by_name": ls.updated_user.full_name if ls.updated_user else None
    }

def create_lead_status(db: Session, ls_data: LeadStatusCreate, login_id: int):
    try:
        # Duplicate check (case-insensitive, not deleted)
        existing_ls = db.query(LeadStatus).filter(
            func.lower(LeadStatus.name) == ls_data.name.lower(),
            LeadStatus.is_deleted == False
        ).first()

        if existing_ls:
            raise HTTPException(
                status_code=400,
                detail=f"Lead Status '{ls_data.name}' already exists."
            )

        # Save exactly as entered (strip only spaces)
        db_ls = LeadStatus(
            name=ls_data.name.strip(),
            description=ls_data.description,
            is_active=ls_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_ls)
        db.commit()
        db.refresh(db_ls)

        return map_lead_status(db_ls)

    except HTTPException:
        raise

    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Lead Status")

    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Lead Status")

def get_lead_statuses(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(LeadStatus).filter(
            LeadStatus.is_deleted == False
        )
        if search:
            query = query.filter(or_(
                LeadStatus.name.ilike(f"%{search}%"),
                LeadStatus.description.ilike(f"%{search}%")
            ))
        total = query.count()
        records = query.order_by(LeadStatus.id.asc()).offset(skip).limit(limit).all()
        return {
            "lead_statuses": [map_lead_status(ls) for ls in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead statuses")

def get_lead_status_by_id(db: Session, ls_id: int):
    try:
        record = db.query(LeadStatus).filter(
            LeadStatus.id == ls_id,
            LeadStatus.is_deleted == False
        ).first()
        return map_lead_status(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch lead status")

def update_lead_status(db: Session, ls_id: int, data: LeadStatusUpdate, login_id: int):
    try:
        db_obj = db.query(LeadStatus).filter(LeadStatus.id == ls_id, LeadStatus.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating name
        if hasattr(data, 'name') and data.name and data.name.lower() != db_obj.name.lower():
            existing = db.query(LeadStatus).filter(
                func.lower(LeadStatus.name) == data.name.lower(),
                LeadStatus.is_deleted == False,
                LeadStatus.id != ls_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Lead Status '{data.name}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead_status(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update lead status")

def delete_lead_status(db: Session, ls_id: int, login_id: int):
    try:
        db_obj = db.query(LeadStatus).filter(LeadStatus.id == ls_id, LeadStatus.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_lead_status(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete lead status")