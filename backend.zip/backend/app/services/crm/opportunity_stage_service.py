from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.crm.opportunity_stage import OpportunityStage
from app.schemas.crm.opportunity_stage import OpportunityStageCreate, OpportunityStageUpdate

def map_opportunity_stage(os: OpportunityStage) -> Optional[Dict[str, Any]]:
    if not os:
        return None
    return {
        "id": os.id,
        "name": os.name,
        "description": os.description,
        "percentage": os.percentage,
        "is_active": os.is_active,
        "is_deleted": os.is_deleted,
        "created_by": os.created_by,
        "updated_by": os.updated_by,
        "created_at": os.created_at,
        "updated_at": os.updated_at,
        "created_by_name": os.created_user.full_name if os.created_user else None,
        "updated_by_name": os.updated_user.full_name if os.updated_user else None
    }

def create_opportunity_stage(db: Session, os_data: OpportunityStageCreate, login_id: int):
    try:
        # Duplicate check (case-insensitive, not deleted)
        existing_os = db.query(OpportunityStage).filter(
            func.lower(OpportunityStage.name) == os_data.name.lower(),
            OpportunityStage.is_deleted == False
        ).first()

        if existing_os:
            raise HTTPException(
                status_code=400,
                detail=f"Opportunity Stage '{os_data.name}' already exists."
            )

        # Save exactly as entered (strip only spaces)
        db_os = OpportunityStage(
            name=os_data.name.strip(),
            description=os_data.description,
            percentage=os_data.percentage,
            is_active=os_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_os)
        db.commit()
        db.refresh(db_os)

        return map_opportunity_stage(db_os)

    except HTTPException:
        raise

    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Opportunity Stage")

    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Opportunity Stage")

def get_opportunity_stages(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(OpportunityStage).filter(
            OpportunityStage.is_deleted == False
        )
        if search:
            query = query.filter(or_(
                OpportunityStage.name.ilike(f"%{search}%"),
                OpportunityStage.description.ilike(f"%{search}%")
            ))
        total = query.count()
        records = query.order_by(OpportunityStage.percentage.asc()).offset(skip).limit(limit).all()
        return {
            "opportunity_stages": [map_opportunity_stage(os) for os in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunity stages")

def get_opportunity_stage_by_id(db: Session, os_id: int):
    try:
        record = db.query(OpportunityStage).filter(
            OpportunityStage.id == os_id,
            OpportunityStage.is_deleted == False
        ).first()
        return map_opportunity_stage(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch opportunity stage")

def update_opportunity_stage(db: Session, os_id: int, data: OpportunityStageUpdate, login_id: int):
    try:
        db_obj = db.query(OpportunityStage).filter(OpportunityStage.id == os_id, OpportunityStage.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating name
        if hasattr(data, 'name') and data.name and data.name.lower() != db_obj.name.lower():
            existing = db.query(OpportunityStage).filter(
                func.lower(OpportunityStage.name) == data.name.lower(),
                OpportunityStage.is_deleted == False,
                OpportunityStage.id != os_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Opportunity Stage '{data.name}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_opportunity_stage(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update opportunity stage")

def delete_opportunity_stage(db: Session, os_id: int, login_id: int):
    try:
        db_obj = db.query(OpportunityStage).filter(OpportunityStage.id == os_id, OpportunityStage.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_opportunity_stage(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete opportunity stage")