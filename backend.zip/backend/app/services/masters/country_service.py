from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.masters.country import Country
from app.schemas.masters.country import CountryCreate, CountryUpdate

def map_country(country: Country) -> Optional[Dict[str, Any]]:
    if not country:
        return None
    return {
        "id": country.id,
        "country_name": country.country_name,
        "country_code": country.country_code,
        "is_active": country.is_active,
        "is_deleted": country.is_deleted,
        "created_by": country.created_by,
        "updated_by": country.updated_by,
        "created_at": country.created_at,
        "updated_at": country.updated_at,
        "created_by_name": country.created_user.full_name if country.created_user else None,
        "updated_by_name": country.updated_user.full_name if country.updated_user else None
    }

def create_country(db: Session, country_data: CountryCreate, login_id: int):
    try:
        # Duplicate check for name and code
        existing_name = db.query(Country).filter(
            func.lower(Country.country_name) == country_data.country_name.lower(),
            Country.is_deleted == False
        ).first()
        if existing_name:
            raise HTTPException(
                status_code=400,
                detail=f"Country '{country_data.country_name}' already exists."
            )
            
        existing_code = db.query(Country).filter(
            func.upper(Country.country_code) == country_data.country_code.upper(),
            Country.is_deleted == False
        ).first()
        if existing_code:
            raise HTTPException(
                status_code=400,
                detail=f"Country code '{country_data.country_code}' already exists."
            )

        db_country = Country(
            country_name=country_data.country_name.strip(),
            country_code=country_data.country_code.upper().strip(),
            is_active=country_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_country)
        db.commit()
        db.refresh(db_country)

        return map_country(db_country)

    except HTTPException:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Country")
    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Country")

def get_countries(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(Country).filter(Country.is_deleted == False)
        if search:
            query = query.filter(or_(
                Country.country_name.ilike(f"%{search}%"),
                Country.country_code.ilike(f"%{search}%")
            ))
        total = query.count()
        records = query.order_by(Country.country_name.asc()).offset(skip).limit(limit).all()
        return {
            "countries": [map_country(country) for country in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch countries")

def get_country_by_id(db: Session, country_id: int):
    try:
        record = db.query(Country).filter(
            Country.id == country_id,
            Country.is_deleted == False
        ).first()
        return map_country(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch country")

def update_country(db: Session, country_id: int, data: CountryUpdate, login_id: int):
    try:
        db_obj = db.query(Country).filter(Country.id == country_id, Country.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating
        if hasattr(data, 'country_name') and data.country_name and data.country_name.lower() != db_obj.country_name.lower():
            existing = db.query(Country).filter(
                func.lower(Country.country_name) == data.country_name.lower(),
                Country.is_deleted == False,
                Country.id != country_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Country '{data.country_name}' already exists."
                )
                
        if hasattr(data, 'country_code') and data.country_code and data.country_code.upper() != db_obj.country_code:
            existing = db.query(Country).filter(
                func.upper(Country.country_code) == data.country_code.upper(),
                Country.is_deleted == False,
                Country.id != country_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Country code '{data.country_code}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            if field == 'country_code' and value:
                value = value.upper().strip()
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_country(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update country")

def delete_country(db: Session, country_id: int, login_id: int):
    try:
        db_obj = db.query(Country).filter(Country.id == country_id, Country.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_country(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete country")

def get_active_countries(db: Session):
    """Get all active countries for dropdown/selection purposes"""
    try:
        records = db.query(Country).filter(
            Country.is_deleted == False,
            Country.is_active == True
        ).order_by(Country.country_name.asc()).all()
        return [{"id": country.id, "name": country.country_name, "code": country.country_code} for country in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch active countries")