from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.masters.job_function import JobFunction
from app.schemas.masters.job_function import JobFunctionCreate, JobFunctionUpdate

def map_job_function(jf: JobFunction) -> Optional[Dict[str, Any]]:
    if not jf:
        return None
    return {
        "id": jf.id,
        "job_function_name": jf.job_function_name,
        "is_active": jf.is_active,
        "is_deleted": jf.is_deleted,
        "created_by": jf.created_by,
        "updated_by": jf.updated_by,
        "created_at": jf.created_at,
        "updated_at": jf.updated_at,
        "created_by_name": jf.created_user.full_name if jf.created_user else None,
        "updated_by_name": jf.updated_user.full_name if jf.updated_user else None
    }

def create_job_function(db: Session, jf_data: JobFunctionCreate, login_id: int):
    try:
        # Duplicate check (case-insensitive, not deleted)
        existing_jf = db.query(JobFunction).filter(
            func.lower(JobFunction.job_function_name) == jf_data.job_function_name.lower(),
            JobFunction.is_deleted == False
        ).first()

        if existing_jf:
            raise HTTPException(
                status_code=400,
                detail=f"Job Function '{jf_data.job_function_name}' already exists."
            )

        # Save exactly as entered (strip only spaces)
        db_jf = JobFunction(
            job_function_name=jf_data.job_function_name.strip(),
            is_active=jf_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_jf)
        db.commit()
        db.refresh(db_jf)

        return map_job_function(db_jf)

    except HTTPException:
        raise

    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Job Function")

    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Job Function")

def get_job_functions(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(JobFunction).filter(
            JobFunction.is_deleted == False
        )
        if search:
            query = query.filter(
                JobFunction.job_function_name.ilike(f"%{search}%")
            )
        total = query.count()
        records = query.order_by(JobFunction.id.asc()).offset(skip).limit(limit).all()
        return {
            "job_functions": [map_job_function(jf) for jf in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch job functions")

def get_job_function_by_id(db: Session, jf_id: int):
    try:
        record = db.query(JobFunction).filter(
            JobFunction.id == jf_id,
            JobFunction.is_deleted == False
        ).first()
        return map_job_function(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch job function")

def update_job_function(db: Session, jf_id: int, data: JobFunctionUpdate, login_id: int):
    try:
        db_obj = db.query(JobFunction).filter(JobFunction.id == jf_id, JobFunction.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating name
        if hasattr(data, 'job_function_name') and data.job_function_name and data.job_function_name.lower() != db_obj.job_function_name.lower():
            existing = db.query(JobFunction).filter(
                func.lower(JobFunction.job_function_name) == data.job_function_name.lower(),
                JobFunction.is_deleted == False,
                JobFunction.id != jf_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Job Function '{data.job_function_name}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_job_function(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update job function")

def delete_job_function(db: Session, jf_id: int, login_id: int):
    try:
        db_obj = db.query(JobFunction).filter(JobFunction.id == jf_id, JobFunction.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_job_function(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete job function")

def get_active_job_functions(db: Session):
    """Get all active job functions for dropdown/selection purposes"""
    try:
        records = db.query(JobFunction).filter(
            JobFunction.is_deleted == False,
            JobFunction.is_active == True
        ).order_by(JobFunction.job_function_name.asc()).all()
        return [{"id": jf.id, "name": jf.job_function_name} for jf in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch active job functions")