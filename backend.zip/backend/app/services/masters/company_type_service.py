from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import or_, func
from fastapi import HTTPException, status
from typing import Optional, Dict, Any
from app.models.masters.company_type import CompanyType
from app.schemas.masters.company_type import CompanyTypeCreate, CompanyTypeUpdate

def map_company_type(ct: CompanyType) -> Optional[Dict[str, Any]]:
    if not ct:
        return None
    return {
        "id": ct.id,
        "type_name": ct.type_name,
        "is_active": ct.is_active,
        "is_deleted": ct.is_deleted,
        "created_by": ct.created_by,
        "updated_by": ct.updated_by,
        "created_at": ct.created_at,
        "updated_at": ct.updated_at,
        "created_by_name": ct.created_user.full_name if ct.created_user else None,
        "updated_by_name": ct.updated_user.full_name if ct.updated_user else None
    }

def create_company_type(db: Session, ct_data: CompanyTypeCreate, login_id: int):
    try:
        # Duplicate check (case-insensitive, not deleted)
        existing_ct = db.query(CompanyType).filter(
            func.lower(CompanyType.type_name) == ct_data.type_name.lower(),
            CompanyType.is_deleted == False
        ).first()

        if existing_ct:
            raise HTTPException(
                status_code=400,
                detail=f"Company Type '{ct_data.type_name}' already exists."
            )

        # Save exactly as entered (strip only spaces)
        db_ct = CompanyType(
            type_name=ct_data.type_name.strip(),
            is_active=ct_data.is_active,
            is_deleted=False,
            created_by=login_id,
            updated_by=login_id
        )

        db.add(db_ct)
        db.commit()
        db.refresh(db_ct)

        return map_company_type(db_ct)

    except HTTPException:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        import traceback
        print("DB Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Database error while creating Company Type")
    except Exception as e:
        db.rollback()
        import traceback
        print("Unexpected Error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Something went wrong while creating Company Type")

def get_company_types(db: Session, skip: int = 0, limit: int = 10, search: Optional[str] = None):
    try:
        query = db.query(CompanyType).filter(CompanyType.is_deleted == False)
        if search:
            query = query.filter(CompanyType.type_name.ilike(f"%{search}%"))
        total = query.count()
        records = query.order_by(CompanyType.id.asc()).offset(skip).limit(limit).all()
        return {
            "company_types": [map_company_type(ct) for ct in records],
            "total": total,
            "limit": limit,
            "page": (skip // limit) + 1
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch company types")

def get_company_type_by_id(db: Session, ct_id: int):
    try:
        record = db.query(CompanyType).filter(
            CompanyType.id == ct_id,
            CompanyType.is_deleted == False
        ).first()
        return map_company_type(record)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch company type")

def update_company_type(db: Session, ct_id: int, data: CompanyTypeUpdate, login_id: int):
    try:
        db_obj = db.query(CompanyType).filter(CompanyType.id == ct_id, CompanyType.is_deleted == False).first()
        if not db_obj:
            return None
        
        # Check for duplicates when updating name
        if hasattr(data, 'type_name') and data.type_name and data.type_name.lower() != db_obj.type_name.lower():
            existing = db.query(CompanyType).filter(
                func.lower(CompanyType.type_name) == data.type_name.lower(),
                CompanyType.is_deleted == False,
                CompanyType.id != ct_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Company Type '{data.type_name}' already exists."
                )
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_company_type(db_obj)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update company type")

def delete_company_type(db: Session, ct_id: int, login_id: int):
    try:
        db_obj = db.query(CompanyType).filter(CompanyType.id == ct_id, CompanyType.is_deleted == False).first()
        if not db_obj:
            return None
        db_obj.is_deleted = True
        db_obj.updated_by = login_id
        db.commit()
        db.refresh(db_obj)
        return map_company_type(db_obj)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete company type")

def get_active_company_types(db: Session):
    """Get all active company types for dropdown/selection purposes"""
    try:
        records = db.query(CompanyType).filter(
            CompanyType.is_deleted == False,
            CompanyType.is_active == True
        ).order_by(CompanyType.type_name.asc()).all()
        return [{"id": ct.id, "name": ct.type_name} for ct in records]
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch active company types")