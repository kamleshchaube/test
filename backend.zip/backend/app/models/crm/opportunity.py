from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, Text, DECIMAL, Date, JSON, CheckConstraint
from sqlalchemy.orm import relationship
from datetime import datetime
import random
from app.database.db import Base

class Opportunity(Base):
    __tablename__ = "crm_opportunities"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pot_id = Column(String(10), unique=True, nullable=False, index=True)
    lead_id = Column(Integer, ForeignKey('crm_leads.id'), nullable=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    contact_id = Column(Integer, ForeignKey('contacts.id'), nullable=False)
    
    # Core fields
    name = Column(String(255), nullable=False)
    stage_id = Column(Integer, ForeignKey('mst_opportunity_stages.id'), nullable=False)
    amount = Column(DECIMAL(15, 2), nullable=True)
    scoring = Column(Integer, default=0)
    bom_id = Column(Integer, nullable=True)
    costing = Column(DECIMAL(15, 2), nullable=True)
    status = Column(String(20), default="Open")
    justification = Column(Text, nullable=True)
    close_date = Column(Date, nullable=True)
    probability = Column(Integer, default=10)
    notes = Column(Text, nullable=True)
    
    # L1 - Qualification Stage Fields
    requirement_gathering_notes = Column(Text, nullable=True)
    go_no_go_status = Column(String(20), default="Pending")
    qualification_completed_by = Column(Integer, ForeignKey('tbl_users.id'), nullable=True)
    qualification_status = Column(String(20), nullable=True)
    qualification_scorecard = Column(JSON, nullable=True)
    
    # L2 - Need Analysis / Demo Stage Fields
    demo_completed = Column(Boolean, default=False)
    demo_date = Column(DateTime, nullable=True)
    demo_summary = Column(Text, nullable=True)
    presentation_materials = Column(JSON, nullable=True)
    qualification_meeting_completed = Column(Boolean, default=False)
    qualification_meeting_date = Column(DateTime, nullable=True)
    qualification_meeting_notes = Column(Text, nullable=True)
    
    # L3 - Proposal / Bid Submission Stage Fields
    quotation_created = Column(Boolean, default=False)
    quotation_status = Column(String(20), default="Draft")
    quotation_file_path = Column(String(500), nullable=True)
    quotation_version = Column(Integer, default=1)
    proposal_prepared = Column(Boolean, default=False)
    proposal_file_path = Column(String(500), nullable=True)
    proposal_submitted = Column(Boolean, default=False)
    proposal_submission_date = Column(DateTime, nullable=True)
    poc_completed = Column(Boolean, default=False)
    poc_notes = Column(Text, nullable=True)
    solutions_team_approval_notes = Column(Text, nullable=True)
    
    # L4 - Negotiation Stage Fields
    customer_discussion_notes = Column(Text, nullable=True)
    proposal_updated = Column(Boolean, default=False)
    updated_proposal_file_path = Column(String(500), nullable=True)
    updated_proposal_submitted = Column(Boolean, default=False)
    negotiated_quotation_file_path = Column(String(500), nullable=True)
    negotiation_rounds = Column(Integer, default=0)
    commercial_approval_required = Column(Boolean, default=False)
    commercial_approval_status = Column(String(50), nullable=True)
    
    # L5 - Won Stage Fields
    kickoff_meeting_scheduled = Column(Boolean, default=False)
    kickoff_meeting_date = Column(DateTime, nullable=True)
    loi_received = Column(Boolean, default=False)
    loi_file_path = Column(String(500), nullable=True)
    order_verified = Column(Boolean, default=False)
    handoff_to_delivery = Column(Boolean, default=False)
    delivery_team_assigned = Column(Integer, ForeignKey('tbl_users.id'), nullable=True)
    
    # Lost/Dropped Stage Fields
    lost_reason = Column(String(255), nullable=True)
    competitor_name = Column(String(255), nullable=True)
    follow_up_date = Column(Date, nullable=True)
    drop_reason = Column(String(255), nullable=True)
    reactivate_date = Column(Date, nullable=True)
    
    # Standard fields
    is_active = Column(Boolean, server_default=text("true"))
    is_deleted = Column(Boolean, server_default=text("false"))
    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Table constraints
    __table_args__ = (
        CheckConstraint("scoring >= 0 AND scoring <= 100", name="check_scoring_range"),
        CheckConstraint("probability >= 0 AND probability <= 100", name="check_probability_range"),
        CheckConstraint("amount >= 0", name="check_amount_positive"),
        CheckConstraint("costing >= 0", name="check_costing_positive"),
    )

    # Relationships
    lead = relationship("Lead", back_populates="opportunities", lazy="joined")
    opportunity_stage = relationship("OpportunityStage", back_populates="opportunities", lazy="joined")
    
    qualification_completer = relationship("User", foreign_keys=[qualification_completed_by], lazy="joined")
    delivery_team_member = relationship("User", foreign_keys=[delivery_team_assigned], lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.pot_id:
            self.pot_id = self._generate_pot_id()

    @staticmethod
    def _generate_pot_id():
        """Generate unique POT-{4digit} ID"""
        return f"POT-{random.randint(1000, 9999)}"

    # Properties
    @property
    def company_name(self):
        """Get company name from company relationship"""
        # This would need to be implemented when Company model is available
        return None  # Placeholder

    @property
    def lead_name(self):
        return self.lead.project_title if self.lead else None

    @property
    def contact_name(self):
        """Get contact name from contact relationship"""
        # This would need to be implemented when Contact model is available
        return None  # Placeholder

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def updater_name(self):
        return self.updated_user.full_name if self.updated_user else None

    @property
    def stage_percentage(self):
        """Return percentage based on stage"""
        return self.opportunity_stage.percentage if self.opportunity_stage else 0

    @property
    def stage_display_name(self):
        """Return user-friendly stage name"""
        if self.opportunity_stage:
            return f"{self.opportunity_stage.name} ({self.opportunity_stage.percentage}%)"
        return "Unknown Stage"

    def __repr__(self):
        return f"<Opportunity(pot_id={self.pot_id}, name={self.name}, stage={self.opportunity_stage.name if self.opportunity_stage else None})>"