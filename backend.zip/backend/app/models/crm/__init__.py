# CRM Models Init

from .lead_source import LeadSource
from .lead_status import LeadStatus
from .lead import Lead
from .opportunity_stage import OpportunityStage
from .opportunity import Opportunity

__all__ = ["LeadSource", "LeadStatus", "Lead", "OpportunityStage", "Opportunity"]