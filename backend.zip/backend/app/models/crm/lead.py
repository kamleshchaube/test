from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, Text, DECIMAL, Date, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base

class Lead(Base):
    __tablename__ = "crm_leads"

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_title = Column(String(255), nullable=False)
    lead_source_id = Column(Integer, ForeignKey('mst_lead_sources.id'), nullable=False)
    lead_status_id = Column(Integer, ForeignKey('mst_lead_statuses.id'), nullable=False)
    
    # Company and Customer Details
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    end_customer_id = Column(Integer, ForeignKey('companies.id'), nullable=True)
    end_customer_region = Column(String(50), nullable=True)
    
    # Business Details
    sub_business_type = Column(String(100), nullable=True)
    products_services = Column(JSON, nullable=True)
    expected_revenue = Column(DECIMAL(15, 2), nullable=False)
    revenue_currency = Column(String(3), default="INR")
    
    # Tender Details
    tender_type = Column(String(100), nullable=True)
    tender_fee = Column(DECIMAL(15, 2), nullable=True)
    currency = Column(String(3), default="INR")
    submission_type = Column(String(50), nullable=True)
    tender_authority = Column(String(255), nullable=True)
    tender_for = Column(Text, nullable=True)
    
    # EMD and BG Details
    emd_required = Column(Boolean, default=False)
    emd_amount = Column(DECIMAL(15, 2), nullable=True)
    emd_currency = Column(String(3), default="INR")
    bg_required = Column(Boolean, default=False)
    bg_amount = Column(DECIMAL(15, 2), nullable=True)
    bg_currency = Column(String(3), default="INR")
    
    # Additional Details
    important_dates = Column(JSON, nullable=True)
    clauses = Column(JSON, nullable=True)
    competitors = Column(JSON, nullable=True)
    documents = Column(JSON, nullable=True)
    contacts = Column(JSON, nullable=True)
    
    # Lead Management
    priority = Column(String(20), default="Medium")
    qualification_notes = Column(Text, nullable=True)
    lead_score = Column(Integer, default=0)
    convert_to_opportunity_date = Column(Date, nullable=True)
    
    # Assignment
    sales_person_id = Column(Integer, ForeignKey('tbl_users.id'), nullable=True)
    
    # Conversion Workflow
    ready_for_conversion = Column(Boolean, default=False)
    conversion_requested = Column(Boolean, default=False)
    conversion_request_date = Column(DateTime, nullable=True)
    conversion_requested_by = Column(Integer, ForeignKey('tbl_users.id'), nullable=True)
    
    # Review and Approval
    reviewed = Column(Boolean, default=False)
    review_status = Column(String(20), default="Pending")
    reviewed_by = Column(Integer, ForeignKey('tbl_users.id'), nullable=True)
    review_date = Column(DateTime, nullable=True)
    review_comments = Column(Text, nullable=True)
    
    # Conversion Tracking
    converted = Column(Boolean, default=False)
    converted_to_opportunity_id = Column(String(10), nullable=True)
    conversion_date = Column(DateTime, nullable=True)
    conversion_notes = Column(Text, nullable=True)
    
    # Standard fields
    is_active = Column(Boolean, server_default=text("true"))
    is_deleted = Column(Boolean, server_default=text("false"))
    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    lead_source = relationship("LeadSource", back_populates="leads", lazy="joined")
    lead_status = relationship("LeadStatus", back_populates="leads", lazy="joined")
    
    # Sales person assignment
    sales_person = relationship("User", foreign_keys=[sales_person_id], lazy="joined")
    conversion_requester = relationship("User", foreign_keys=[conversion_requested_by], lazy="joined")
    reviewer = relationship("User", foreign_keys=[reviewed_by], lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)
    
    # One-to-many with opportunities
    opportunities = relationship("Opportunity", back_populates="lead")

    @property
    def company_name(self):
        """Get company name from company relationship"""
        # This would need to be implemented when Company model is available
        return None  # Placeholder

    @property
    def end_customer_name(self):
        """Get end customer name from company relationship"""
        # This would need to be implemented when Company model is available
        return None  # Placeholder

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def sales_person_name(self):
        return self.sales_person.full_name if self.sales_person else None

    @property
    def conversion_requester_name(self):
        return self.conversion_requester.full_name if self.conversion_requester else None

    @property
    def reviewer_name(self):
        return self.reviewer.full_name if self.reviewer else None

    @property
    def can_request_conversion(self):
        """Check if lead can request conversion"""
        return (
            self.lead_status.name == "Qualified" and 
            not self.converted and 
            not self.conversion_requested
        )

    @property
    def can_convert_to_opportunity(self):
        """Check if lead can be converted to opportunity"""
        return (
            self.lead_status.name == "Qualified" and
            not self.converted and
            self.reviewed and
            self.review_status == "Approved"
        )

    @property
    def needs_admin_review(self):
        """Check if lead needs admin review before conversion"""
        return (
            self.lead_status.name == "Qualified" and
            self.conversion_requested and
            not self.reviewed
        )

    def __repr__(self):
        return f"<Lead(project_title={self.project_title}, status={self.lead_status.name if self.lead_status else None})>"