from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base

class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=True)
    email = Column(String(150), nullable=False, unique=True)
    phone = Column(String(20), nullable=True)
    mobile = Column(String(20), nullable=True)
    designation_id = Column(Integer, ForeignKey('mst_head_of_companies.id'), nullable=True)
    department = Column(String(100), nullable=True)
    is_primary = Column(Boolean, server_default=text("false"))
    
    is_active = Column(Boolean, server_default=text("true"))
    is_deleted = Column(Boolean, server_default=text("false"))

    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company = relationship("Company", back_populates="contacts")
    designation = relationship("HeadOfCompany", back_populates="contacts", lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def designation_name(self):
        return self.designation.head_role_name if self.designation else None

    @property
    def company_name(self):
        return self.company.company_name if self.company else None