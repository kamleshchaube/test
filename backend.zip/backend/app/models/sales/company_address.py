from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base

class CompanyAddress(Base):
    __tablename__ = "company_addresses"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    address_type_id = Column(Integer, ForeignKey('mst_address_types.id'), nullable=False)
    address = Column(Text, nullable=False)
    country_id = Column(Integer, ForeignKey('mst_countries.id'), nullable=False)
    state_id = Column(Integer, ForeignKey('mst_states.id'), nullable=False)
    city_id = Column(Integer, ForeignKey('mst_cities.id'), nullable=False)
    zipcode = Column(String(20), nullable=True)
    
    is_deleted = Column(Boolean, server_default=text("false"))

    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company = relationship("Company", back_populates="addresses")
    address_type = relationship("AddressType", back_populates="company_addresses", lazy="joined")
    country = relationship("Country", back_populates="company_addresses", lazy="joined")
    state = relationship("State", back_populates="company_addresses", lazy="joined")
    city = relationship("City", back_populates="company_addresses", lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    @property
    def full_address(self):
        return f"{self.address}, {self.city.city_name if self.city else ''}, {self.state.state_name if self.state else ''}, {self.country.country_name if self.country else ''} - {self.zipcode or ''}".strip()

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def address_type_name(self):
        return self.address_type.address_type_name if self.address_type else None