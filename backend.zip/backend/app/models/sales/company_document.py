from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base

class CompanyDocument(Base):
    __tablename__ = "company_documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    document_type_id = Column(Integer, ForeignKey('mst_document_types.id'), nullable=False)
    file_path = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    is_deleted = Column(Boolean, server_default=text("false"))

    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company = relationship("Company", back_populates="documents")
    document_type = relationship("DocumentType", back_populates="company_documents", lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def document_type_name(self):
        return self.document_type.document_type_name if self.document_type else None