from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, DECIMAL, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base
import enum

class FinancialType(str, enum.Enum):
    TURNOVER = "turnover"
    PROFIT = "profit"
    REVENUE = "revenue"

class CompanyFinancial(Base):
    __tablename__ = "company_financials"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    year = Column(String(4), nullable=False)  # Using String for YEAR equivalent
    revenue = Column(DECIMAL(18, 2), nullable=True)
    profit = Column(DECIMAL(18, 2), nullable=True)
    currency_id = Column(Integer, ForeignKey('mst_currencies.id'), nullable=False)
    type = Column(Enum(FinancialType), nullable=False)
    
    is_deleted = Column(Boolean, server_default=text("false"))

    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company = relationship("Company", back_populates="financials")
    currency = relationship("Currency", back_populates="company_financials", lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def currency_code(self):
        return self.currency.currency_code if self.currency else None