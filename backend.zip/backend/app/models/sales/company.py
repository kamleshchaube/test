from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, text, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.db import Base

class Company(Base):
    __tablename__ = "companies"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_code = Column(String(100), nullable=False, unique=True)
    company_name = Column(String(255), nullable=False)
    company_type_id = Column(Integer, ForeignKey('mst_company_types.id'), nullable=True)
    gst_no = Column(String(50), nullable=False)
    pan_no = Column(String(50), nullable=False)
    account_type_id = Column(Integer, ForeignKey('mst_account_types.id'), nullable=True)
    account_region_id = Column(Integer, ForeignKey('mst_regions.id'), nullable=True)
    business_type_id = Column(Integer, ForeignKey('mst_business_types.id'), nullable=True)
    industry_segment_id = Column(Integer, ForeignKey('mst_industry_segments.id'), nullable=True)
    sub_industry_segment_id = Column(Integer, ForeignKey('mst_sub_industry_segments.id'), nullable=True)
    partner_type_id = Column(Integer, ForeignKey('mst_partner_types.id'), nullable=True)
    head_of_company_id = Column(Integer, ForeignKey('mst_head_of_companies.id'), nullable=True)
    website = Column(String(255), nullable=True)
    is_active = Column(Boolean, server_default=text("true"))
    is_child = Column(Boolean, server_default=text("false"))
    remarks = Column(Text, nullable=True)
    is_deleted = Column(Boolean, server_default=text("false"))

    created_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    updated_by = Column(Integer, ForeignKey('tbl_users.id', ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company_type = relationship("CompanyType", back_populates="companies", lazy="joined")
    account_type = relationship("AccountType", back_populates="companies", lazy="joined")
    business_type = relationship("BusinessType", back_populates="companies", lazy="joined")
    industry_segment = relationship("IndustrySegment", back_populates="companies", lazy="joined")
    sub_industry_segment = relationship("SubIndustrySegment", back_populates="companies", lazy="joined")
    partner_type = relationship("PartnerType", back_populates="companies", lazy="joined")
    head_of_company = relationship("HeadOfCompany", back_populates="companies", lazy="joined")
    
    created_user = relationship("User", foreign_keys=[created_by], lazy="joined", post_update=True)
    updated_user = relationship("User", foreign_keys=[updated_by], lazy="joined", post_update=True)

    # Reverse relationships
    addresses = relationship("CompanyAddress", back_populates="company", cascade="all, delete-orphan")
    documents = relationship("CompanyDocument", back_populates="company", cascade="all, delete-orphan")
    financials = relationship("CompanyFinancial", back_populates="company", cascade="all, delete-orphan")
    contacts = relationship("Contact", back_populates="company", cascade="all, delete-orphan")

    @property
    def creator_name(self):
        return self.created_user.full_name if self.created_user else None

    @property
    def updater_name(self):
        return self.updated_user.full_name if self.updated_user else None

    @property
    def company_type_name(self):
        return self.company_type.type_name if self.company_type else None

    @property
    def industry_name(self):
        return self.industry_segment.industry_name if self.industry_segment else None

    @property
    def primary_contact(self):
        return next((contact for contact in self.contacts if contact.is_primary and not contact.is_deleted), None)