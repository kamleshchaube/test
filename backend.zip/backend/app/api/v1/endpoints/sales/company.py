from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.models.sales.company import Company
from app.schemas.user_management.user import UserResponse
from app.schemas.sales import company as CompanySchema
from app.schemas.sales.company import CompanyExportOut
from app.services.sales import company_service as CompanyService

router = APIRouter()

# Helper for consistent error handling
def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

# ---------------- CREATE ----------------
@router.post(
    "/",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "create")],
    status_code=status.HTTP_201_CREATED
)
def create_company(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    data: CompanySchema.CompanyCreate,
    db: Session = Depends(get_db)
):
    try:
        result = CompanyService.create_company(db, data, login_id=current_user.id)
        return Response(
            json_data=result,
            message="Company created successfully",
            status_code=status.HTTP_201_CREATED
        )
    except Exception as e:
        return handle_exception(e, "Creating Company failed", getattr(e, "status_code", 500))

# ---------------- LIST ----------------
@router.get(
    "/",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "view")],
    status_code=status.HTTP_200_OK
)
def list_companies(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
    page: int = Query(1, ge=1),
    search: Optional[str] = Query(None),
    company_type_id: Optional[int] = Query(None),
    industry_id: Optional[int] = Query(None),
    is_active: Optional[bool] = Query(None)
):
    try:
        offset = (page - 1) * limit
        result = CompanyService.get_companies(
            db, skip=offset, limit=limit, search=search,
            company_type_id=company_type_id, industry_id=industry_id,
            is_active=is_active
        )
        return Response(
            json_data=result,
            message="Companies fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching Companies failed", getattr(e, "status_code", 500))

# ---------------- GET BY ID ----------------
@router.get(
    "/{company_id}",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "view")],
    status_code=status.HTTP_200_OK
)
def get_company(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    company_id: int,
    db: Session = Depends(get_db),
    include_related: bool = Query(False, description="Include related data (addresses, contacts, documents, financials)")
):
    try:
        result = CompanyService.get_company_by_id(db, company_id, include_related=include_related)
        if not result:
            return handle_exception(Exception("Company not found"), "Fetching Company by ID failed", 404)
        return Response(
            json_data=result,
            message="Company fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Failed to fetch company")

# ---------------- UPDATE ----------------  
@router.put(
    "/{company_id}",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "edit")],
    status_code=status.HTTP_200_OK
)
def update_company(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    company_id: int,
    data: CompanySchema.CompanyUpdate,
    db: Session = Depends(get_db)
):
    try:
        updated = CompanyService.update_company(db, company_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Company not found"), "Updating Company failed", 404)
        return Response(
            json_data=updated,
            message="Company updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Company update failed")

# ---------------- DELETE ----------------
@router.delete(
    "/{company_id}",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "delete")],
    status_code=status.HTTP_200_OK
)
def delete_company(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    company_id: int,
    db: Session = Depends(get_db)
):
    try:
        deleted = CompanyService.delete_company(db, company_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Company not found"), "Deleting Company failed", 404)
        return Response(
            json_data=deleted,
            message="Company deleted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Deleting Company failed", getattr(e, "status_code", 500))

# ---------------- STATISTICS ----------------
@router.get(
    "/stats/summary",
    response_model=CompanySchema.CompanyResponse,
    dependencies=[check_permission(3, "/companies", "view")],
    status_code=status.HTTP_200_OK
)
def get_company_stats(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db)
):
    try:
        result = CompanyService.get_company_stats(db)
        return Response(
            json_data=result,
            message="Company statistics fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching company stats failed", getattr(e, "status_code", 500))

# ---------------- EXPORT ----------------
@router.get(
    "/export/csv",
    dependencies=[check_permission(3, "/companies", "export")],
    status_code=status.HTTP_200_OK
)
def export_companies(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    company_type_id: Optional[int] = Query(None),
    industry_id: Optional[int] = Query(None),
    is_active: Optional[bool] = Query(None)
):
    try:
        # Get filtered companies for export
        companies_data = CompanyService.get_companies(
            db, skip=0, limit=10000,  # Large limit for export
            company_type_id=company_type_id,
            industry_id=industry_id,
            is_active=is_active
        )
        
        export_data = []
        for company in companies_data["companies"]:
            export_data.append({
                "company_code": company["company_code"],
                "company_name": company["company_name"],
                "gst_no": company["gst_no"],
                "pan_no": company["pan_no"],
                "website": company["website"],
                "is_active": company["is_active"],
                "company_type_name": company["company_type_name"],
                "industry_name": company["industry_name"],
                "created_by_name": company["created_by_name"],
                "updated_by_name": company["updated_by_name"],
                "created_at": company["created_at"],
                "updated_at": company["updated_at"],
            })
        
        return Response(
            json_data=export_data,
            message="Companies exported successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Exporting Companies failed", getattr(e, "status_code", 500))

# ---------------- BULK OPERATIONS ----------------
@router.post(
    "/bulk/activate",
    dependencies=[check_permission(3, "/companies", "edit")],
    status_code=status.HTTP_200_OK
)
def bulk_activate_companies(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    company_ids: list[int],
    db: Session = Depends(get_db)
):
    try:
        updated_count = 0
        for company_id in company_ids:
            company = db.query(Company).filter(
                Company.id == company_id,
                Company.is_deleted == False
            ).first()
            if company:
                company.is_active = True
                company.updated_by = current_user.id
                updated_count += 1
        
        db.commit()
        
        return Response(
            json_data={"updated_count": updated_count},
            message=f"{updated_count} companies activated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        db.rollback()
        return handle_exception(e, "Bulk activation failed", 500)

@router.post(
    "/bulk/deactivate",
    dependencies=[check_permission(3, "/companies", "edit")],
    status_code=status.HTTP_200_OK
)
def bulk_deactivate_companies(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    company_ids: list[int],
    db: Session = Depends(get_db)
):
    try:
        updated_count = 0
        for company_id in company_ids:
            company = db.query(Company).filter(
                Company.id == company_id,
                Company.is_deleted == False
            ).first()
            if company:
                company.is_active = False
                company.updated_by = current_user.id
                updated_count += 1
        
        db.commit()
        
        return Response(
            json_data={"updated_count": updated_count},
            message=f"{updated_count} companies deactivated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        db.rollback()
        return handle_exception(e, "Bulk deactivation failed", 500)