from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.models.masters.job_function import JobFunction
from app.schemas.user_management.user import UserResponse
from app.schemas.masters import job_function as JFSchema
from app.schemas.masters.job_function import JobFunctionExportOut
from app.services.masters import job_function_service as JFService

router = APIRouter()

# Helper for consistent error handling
def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

# ---------------- CREATE ----------------
@router.post(
    "/",
    response_model=JFSchema.JobFunctionResponse,
    dependencies=[check_permission(3, "/job-functions", "create")],
    status_code=status.HTTP_201_CREATED
)
def create_job_function(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    data: JFSchema.JobFunctionCreate,
    db: Session = Depends(get_db)
):
    try:
        result = JFService.create_job_function(db, data, login_id=current_user.id)
        return Response(
            json_data=result,
            message="Job function created successfully",
            status_code=status.HTTP_201_CREATED
        )
    except Exception as e:
        return handle_exception(e, "Creating Job Function failed", getattr(e, "status_code", 500))

# ---------------- LIST ----------------
@router.get(
    "/",
    response_model=JFSchema.JobFunctionResponse,
    dependencies=[check_permission(3, "/job-functions", "view")],
    status_code=status.HTTP_200_OK
)
def list_job_functions(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
    page: int = Query(1, ge=1),
    search: Optional[str] = Query(None)
):
    try:
        offset = (page - 1) * limit
        result = JFService.get_job_functions(db, skip=offset, limit=limit, search=search)
        return Response(
            json_data=result,
            message="Job functions fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching Job Functions failed", getattr(e, "status_code", 500))

# ---------------- GET ACTIVE (DROPDOWN) ----------------
@router.get(
    "/active",
    dependencies=[check_permission(3, "/job-functions", "view")],
    status_code=status.HTTP_200_OK
)
def get_active_job_functions(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db)
):
    try:
        result = JFService.get_active_job_functions(db)
        return Response(
            json_data=result,
            message="Active job functions fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching active Job Functions failed", getattr(e, "status_code", 500))

# ---------------- GET BY ID ----------------
@router.get(
    "/{jf_id}",
    response_model=JFSchema.JobFunctionResponse,
    dependencies=[check_permission(3, "/job-functions", "view")],
    status_code=status.HTTP_200_OK
)
def get_job_function(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    jf_id: int,
    db: Session = Depends(get_db)
):
    try:
        result = JFService.get_job_function_by_id(db, jf_id)
        if not result:
            return handle_exception(Exception("Job Function not found"), "Fetching Job Function by ID failed", 404)
        return Response(
            json_data=result,
            message="Job function fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Failed to fetch job function")

# ---------------- UPDATE ----------------
@router.put(
    "/{jf_id}",
    response_model=JFSchema.JobFunctionResponse,
    dependencies=[check_permission(3, "/job-functions", "edit")],
    status_code=status.HTTP_200_OK
)
def update_job_function(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    jf_id: int,
    data: JFSchema.JobFunctionUpdate,
    db: Session = Depends(get_db)
):
    try:
        updated = JFService.update_job_function(db, jf_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Job Function not found"), "Updating Job Function failed", 404)
        return Response(
            json_data=updated,
            message="Job function updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Job function update failed")

# ---------------- DELETE ----------------
@router.delete(
    "/{jf_id}",
    response_model=JFSchema.JobFunctionResponse,
    dependencies=[check_permission(3, "/job-functions", "delete")],
    status_code=status.HTTP_200_OK
)
def delete_job_function(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    jf_id: int,
    db: Session = Depends(get_db)
):
    try:
        deleted = JFService.delete_job_function(db, jf_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Job function not found"), "Deleting Job Function failed", 404)
        return Response(
            json_data=deleted,
            message="Job function deleted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Deleting Job Function failed", getattr(e, "status_code", 500))

# ---------------- EXPORT ----------------
@router.get(
    "/export/csv",
    dependencies=[check_permission(3, "/job-functions", "export")],
    status_code=status.HTTP_200_OK
)
def export_job_functions(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
):
    try:
        job_functions = db.query(JobFunction).filter(JobFunction.is_deleted == False).all()
        export_data = []
        for jf in job_functions:
            export_data.append({
                "job_function_name": jf.job_function_name,
                "is_active": jf.is_active,
                "created_by_name": jf.created_user.full_name if jf.created_user else None,
                "updated_by_name": jf.updated_user.full_name if jf.updated_user else None,
                "created_at": jf.created_at,
                "updated_at": jf.updated_at,
            })
        
        return Response(
            json_data=export_data,
            message="Job functions exported successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Exporting Job Functions failed", getattr(e, "status_code", 500))