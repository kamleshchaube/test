from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.schemas.user_management.user import UserResponse
from app.schemas.crm import opportunity as OppSchema
from app.services.crm import opportunity_service as OppService

router = APIRouter()

def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

# ---------------- CREATE ----------------
@router.post(
    "/",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "create")],
    status_code=status.HTTP_201_CREATED
)
def create_opportunity(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    data: OppSchema.OpportunityCreate,
    db: Session = Depends(get_db)
):
    try:
        result = OppService.create_opportunity(db, data, login_id=current_user.id)
        return Response(
            json_data=result,
            message="Opportunity created successfully",
            status_code=status.HTTP_201_CREATED
        )
    except Exception as e:
        return handle_exception(e, "Creating Opportunity failed", getattr(e, "status_code", 500))

# ---------------- LIST ----------------
@router.get(
    "/",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "view")],
    status_code=status.HTTP_200_OK
)
def list_opportunities(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
    page: int = Query(1, ge=1),
    search: Optional[str] = Query(None),
    stage_filter: Optional[str] = Query(None),
    status_filter: Optional[str] = Query(None),
    company_id: Optional[int] = Query(None),
    lead_id: Optional[int] = Query(None)
):
    try:
        offset = (page - 1) * limit
        
        if company_id:
            opportunities = OppService.get_opportunities_by_company(db, company_id, offset, limit)
            total = len(opportunities)  # Simplified count
        elif lead_id:
            opportunities = OppService.get_opportunities_by_lead(db, lead_id, offset, limit)
            total = len(opportunities)  # Simplified count
        else:
            result = OppService.get_opportunities(
                db, skip=offset, limit=limit, search=search,
                stage_filter=stage_filter, status_filter=status_filter
            )
            opportunities = result["opportunities"]
            total = result["total"]
        
        return Response(
            json_data={
                "opportunities": opportunities,
                "total": total,
                "limit": limit,
                "page": page
            },
            message="Opportunities fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching Opportunities failed", getattr(e, "status_code", 500))

# ---------------- GET BY ID ----------------
@router.get(
    "/{opp_id}",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "view")],
    status_code=status.HTTP_200_OK
)
def get_opportunity(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    opp_id: int,
    db: Session = Depends(get_db)
):
    try:
        result = OppService.get_opportunity_by_id(db, opp_id)
        if not result:
            return handle_exception(Exception("Opportunity not found"), "Fetching Opportunity by ID failed", 404)
        return Response(
            json_data=result,
            message="Opportunity fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Failed to fetch opportunity")

# ---------------- UPDATE ----------------
@router.put(
    "/{opp_id}",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "edit")],
    status_code=status.HTTP_200_OK
)
def update_opportunity(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    opp_id: int,
    data: OppSchema.OpportunityUpdate,
    db: Session = Depends(get_db)
):
    try:
        updated = OppService.update_opportunity(db, opp_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Opportunity not found"), "Updating Opportunity failed", 404)
        return Response(
            json_data=updated,
            message="Opportunity updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Opportunity update failed")

# ---------------- STAGE UPDATE ----------------
@router.patch(
    "/{opp_id}/stage",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "edit")],
    status_code=status.HTTP_200_OK
)
def update_opportunity_stage(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    opp_id: int,
    stage_data: OppSchema.OpportunityStageUpdate,
    db: Session = Depends(get_db)
):
    try:
        # Get the stage name from stage_id
        from app.models.crm.opportunity_stage import OpportunityStage
        stage = db.query(OpportunityStage).filter(OpportunityStage.id == stage_data.stage_id).first()
        if not stage:
            return handle_exception(Exception("Stage not found"), "Invalid stage", 400)
        
        result = OppService.update_stage(
            db, opp_id, stage.name, current_user.id, 
            stage_data.notes, stage_data.stage_specific_data
        )
        if not result:
            return handle_exception(Exception("Opportunity not found"), "Updating stage failed", 404)
        return Response(
            json_data=result,
            message="Opportunity stage updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Stage update failed", getattr(e, "status_code", 500))

# ---------------- CLOSE OPPORTUNITY ----------------
@router.patch(
    "/{opp_id}/close",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "edit")],
    status_code=status.HTTP_200_OK
)
def close_opportunity(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    opp_id: int,
    close_data: OppSchema.OpportunityCloseRequest,
    db: Session = Depends(get_db)
):
    try:
        result = OppService.close_opportunity(
            db, opp_id, close_data.status, close_data.close_date.isoformat(),
            current_user.id, close_data.notes, close_data.lost_reason,
            close_data.competitor_name, close_data.drop_reason
        )
        if not result:
            return handle_exception(Exception("Opportunity not found"), "Closing opportunity failed", 404)
        return Response(
            json_data=result,
            message=f"Opportunity closed as {close_data.status}",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Close opportunity failed", getattr(e, "status_code", 500))

# ---------------- DELETE ----------------
@router.delete(
    "/{opp_id}",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "delete")],
    status_code=status.HTTP_200_OK
)
def delete_opportunity(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    opp_id: int,
    db: Session = Depends(get_db)
):
    try:
        deleted = OppService.delete_opportunity(db, opp_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Opportunity not found"), "Deleting Opportunity failed", 404)
        return Response(
            json_data=deleted,
            message="Opportunity deleted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Deleting Opportunity failed", getattr(e, "status_code", 500))

# ---------------- ANALYTICS ----------------
@router.get(
    "/pipeline/summary",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "view")],
    status_code=status.HTTP_200_OK
)
def get_pipeline_summary(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    user_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    try:
        result = OppService.get_pipeline_summary(db, user_id)
        return Response(
            json_data=result,
            message="Pipeline summary fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching pipeline summary failed", getattr(e, "status_code", 500))

@router.get(
    "/analytics/metrics",
    response_model=OppSchema.OpportunityResponse,
    dependencies=[check_permission(2, "/opportunities", "view")],
    status_code=status.HTTP_200_OK
)
def get_opportunity_metrics(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    user_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    try:
        result = OppService.get_opportunity_metrics(db, user_id)
        return Response(
            json_data=result,
            message="Opportunity metrics fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching opportunity metrics failed", getattr(e, "status_code", 500))