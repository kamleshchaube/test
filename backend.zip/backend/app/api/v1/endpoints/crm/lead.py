from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.schemas.user_management.user import UserResponse
from app.schemas.crm import lead as LeadSchema
from app.services.crm import lead_service as LeadService

router = APIRouter()

def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

# ---------------- CREATE ----------------
@router.post(
    "/",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "create")],
    status_code=status.HTTP_201_CREATED
)
def create_lead(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    data: LeadSchema.LeadCreate,
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.create_lead(db, data, login_id=current_user.id)
        return Response(
            json_data=result,
            message="Lead created successfully",
            status_code=status.HTTP_201_CREATED
        )
    except Exception as e:
        return handle_exception(e, "Creating Lead failed", getattr(e, "status_code", 500))

# ---------------- LIST ----------------
@router.get(
    "/",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "view")],
    status_code=status.HTTP_200_OK
)
def list_leads(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
    page: int = Query(1, ge=1),
    search: Optional[str] = Query(None),
    status_filter: Optional[str] = Query(None),
    company_id: Optional[int] = Query(None),
    review_status: Optional[str] = Query(None)
):
    try:
        offset = (page - 1) * limit
        result = LeadService.get_leads(
            db, skip=offset, limit=limit, search=search,
            status_filter=status_filter, company_id=company_id,
            review_status=review_status
        )
        return Response(
            json_data=result,
            message="Leads fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching Leads failed", getattr(e, "status_code", 500))

# ---------------- GET BY ID ----------------
@router.get(
    "/{lead_id}",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "view")],
    status_code=status.HTTP_200_OK
)
def get_lead(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    lead_id: int,
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.get_lead_by_id(db, lead_id)
        if not result:
            return handle_exception(Exception("Lead not found"), "Fetching Lead by ID failed", 404)
        return Response(
            json_data=result,
            message="Lead fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Failed to fetch lead")

# ---------------- UPDATE ----------------
@router.put(
    "/{lead_id}",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "edit")],
    status_code=status.HTTP_200_OK
)
def update_lead(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    lead_id: int,
    data: LeadSchema.LeadUpdate,
    db: Session = Depends(get_db)
):
    try:
        updated = LeadService.update_lead(db, lead_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Lead not found"), "Updating Lead failed", 404)
        return Response(
            json_data=updated,
            message="Lead updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Lead update failed")

# ---------------- DELETE ----------------
@router.delete(
    "/{lead_id}",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "delete")],
    status_code=status.HTTP_200_OK
)
def delete_lead(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    lead_id: int,
    db: Session = Depends(get_db)
):
    try:
        deleted = LeadService.delete_lead(db, lead_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Lead not found"), "Deleting Lead failed", 404)
        return Response(
            json_data=deleted,
            message="Lead deleted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Deleting Lead failed", getattr(e, "status_code", 500))

# ---------------- CONVERSION WORKFLOW ----------------
@router.post(
    "/{lead_id}/request-conversion",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "edit")],
    status_code=status.HTTP_200_OK
)
def request_conversion(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    lead_id: int,
    request_data: LeadSchema.ConversionRequestSchema,
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.request_conversion(db, lead_id, current_user.id, request_data.notes)
        if not result:
            return handle_exception(Exception("Lead not found"), "Requesting conversion failed", 404)
        return Response(
            json_data=result,
            message="Conversion request submitted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Conversion request failed", getattr(e, "status_code", 500))

@router.post(
    "/{lead_id}/review",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "edit")],  # This should be admin-only in production
    status_code=status.HTTP_200_OK
)
def review_conversion_request(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    lead_id: int,
    review_data: LeadSchema.ReviewDecisionSchema,
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.review_conversion_request(
            db, lead_id, current_user.id, review_data.decision, review_data.comments
        )
        if not result:
            return handle_exception(Exception("Lead not found"), "Reviewing conversion failed", 404)
        return Response(
            json_data=result,
            message=f"Conversion request {review_data.decision.lower()} successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Review failed", getattr(e, "status_code", 500))

# ---------------- STATS ----------------
@router.get(
    "/stats/summary",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "view")],
    status_code=status.HTTP_200_OK
)
def get_lead_stats(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.get_lead_stats(db)
        return Response(
            json_data=result,
            message="Lead statistics fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching lead stats failed", getattr(e, "status_code", 500))

@router.get(
    "/pending-review",
    response_model=LeadSchema.LeadResponse,
    dependencies=[check_permission(2, "/leads", "view")],  # This should be admin-only in production
    status_code=status.HTTP_200_OK
)
def get_pending_review_leads(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db)
):
    try:
        result = LeadService.get_leads_pending_review(db)
        return Response(
            json_data={"leads": result},
            message="Pending review leads fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching pending leads failed", getattr(e, "status_code", 500))