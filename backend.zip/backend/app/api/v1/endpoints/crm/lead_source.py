from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.models.crm.lead_source import LeadSource
from app.schemas.user_management.user import UserResponse
from app.schemas.crm import lead_source as LSSchema
from app.schemas.crm.lead_source import LeadSourceExportOut
from app.services.crm import lead_source_service as LSService

router = APIRouter()

# Helper for consistent error handling
def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

# ---------------- CREATE ----------------
@router.post(
    "/",
    response_model=LSSchema.LeadSourceResponse,
    dependencies=[check_permission(2, "/lead-sources", "create")],
    status_code=status.HTTP_201_CREATED
)
def create_lead_source(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    data: LSSchema.LeadSourceCreate,
    db: Session = Depends(get_db)
):
    try:
        result = LSService.create_lead_source(db, data, login_id=current_user.id)
        return Response(
            json_data=result,
            message="Lead source created successfully",
            status_code=status.HTTP_201_CREATED
        )
    except Exception as e:
        return handle_exception(e, "Creating Lead Source failed", getattr(e, "status_code", 500))

# ---------------- LIST ----------------
@router.get(
    "/",
    response_model=LSSchema.LeadSourceResponse,
    dependencies=[check_permission(2, "/lead-sources", "view")],
    status_code=status.HTTP_200_OK
)
def list_lead_sources(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    db: Session = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
    page: int = Query(1, ge=1),
    search: Optional[str] = Query(None)
):
    try:
        offset = (page - 1) * limit
        result = LSService.get_lead_sources(db, skip=offset, limit=limit, search=search)
        return Response(
            json_data=result,
            message="Lead sources fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Fetching Lead Sources failed", getattr(e, "status_code", 500))

# ---------------- GET BY ID ----------------
@router.get(
    "/{ls_id}",
    response_model=LSSchema.LeadSourceResponse,
    dependencies=[check_permission(2, "/lead-sources", "view")],
    status_code=status.HTTP_200_OK
)
def get_lead_source(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    ls_id: int,
    db: Session = Depends(get_db)
):
    try:
        result = LSService.get_lead_source_by_id(db, ls_id)
        if not result:
            return handle_exception(Exception("Lead Source not found"), "Fetching Lead Source by ID failed", 404)
        return Response(
            json_data=result,
            message="Lead source fetched successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Failed to fetch lead source")

# ---------------- UPDATE ----------------
@router.put(
    "/{ls_id}",
    response_model=LSSchema.LeadSourceResponse,
    dependencies=[check_permission(2, "/lead-sources", "edit")],
    status_code=status.HTTP_200_OK
)
def update_lead_source(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    ls_id: int,
    data: LSSchema.LeadSourceUpdate,
    db: Session = Depends(get_db)
):
    try:
        updated = LSService.update_lead_source(db, ls_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Lead Source not found"), "Updating Lead Source failed", 404)
        return Response(
            json_data=updated,
            message="Lead source updated successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Lead source update failed")

# ---------------- DELETE ----------------
@router.delete(
    "/{ls_id}",
    response_model=LSSchema.LeadSourceResponse,
    dependencies=[check_permission(2, "/lead-sources", "delete")],
    status_code=status.HTTP_200_OK
)
def delete_lead_source(
    current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)],
    ls_id: int,
    db: Session = Depends(get_db)
):
    try:
        deleted = LSService.delete_lead_source(db, ls_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Lead source not found"), "Deleting Lead Source failed", 404)
        return Response(
            json_data=deleted,
            message="Lead source deleted successfully",
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        return handle_exception(e, "Deleting Lead Source failed", getattr(e, "status_code", 500))