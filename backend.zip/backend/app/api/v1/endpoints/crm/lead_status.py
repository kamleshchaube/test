from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.schemas.user_management.user import UserResponse
from app.schemas.crm import lead_status as LSSchema
from app.services.crm import lead_status_service as LSService

router = APIRouter()

def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

@router.post("/", response_model=LSSchema.LeadStatusResponse, dependencies=[check_permission(2, "/lead-statuses", "create")], status_code=status.HTTP_201_CREATED)
def create_lead_status(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], data: LSSchema.LeadStatusCreate, db: Session = Depends(get_db)):
    try:
        result = LSService.create_lead_status(db, data, login_id=current_user.id)
        return Response(json_data=result, message="Lead status created successfully", status_code=status.HTTP_201_CREATED)
    except Exception as e:
        return handle_exception(e, "Creating Lead Status failed", getattr(e, "status_code", 500))

@router.get("/", response_model=LSSchema.LeadStatusResponse, dependencies=[check_permission(2, "/lead-statuses", "view")], status_code=status.HTTP_200_OK)
def list_lead_statuses(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], db: Session = Depends(get_db), limit: int = Query(10, ge=1, le=100), page: int = Query(1, ge=1), search: Optional[str] = Query(None)):
    try:
        offset = (page - 1) * limit
        result = LSService.get_lead_statuses(db, skip=offset, limit=limit, search=search)
        return Response(json_data=result, message="Lead statuses fetched successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Fetching Lead Statuses failed", getattr(e, "status_code", 500))

@router.get("/{ls_id}", response_model=LSSchema.LeadStatusResponse, dependencies=[check_permission(2, "/lead-statuses", "view")], status_code=status.HTTP_200_OK)
def get_lead_status(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], ls_id: int, db: Session = Depends(get_db)):
    try:
        result = LSService.get_lead_status_by_id(db, ls_id)
        if not result:
            return handle_exception(Exception("Lead Status not found"), "Fetching Lead Status by ID failed", 404)
        return Response(json_data=result, message="Lead status fetched successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Failed to fetch lead status")

@router.put("/{ls_id}", response_model=LSSchema.LeadStatusResponse, dependencies=[check_permission(2, "/lead-statuses", "edit")], status_code=status.HTTP_200_OK)
def update_lead_status(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], ls_id: int, data: LSSchema.LeadStatusUpdate, db: Session = Depends(get_db)):
    try:
        updated = LSService.update_lead_status(db, ls_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Lead Status not found"), "Updating Lead Status failed", 404)
        return Response(json_data=updated, message="Lead status updated successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Lead status update failed")

@router.delete("/{ls_id}", response_model=LSSchema.LeadStatusResponse, dependencies=[check_permission(2, "/lead-statuses", "delete")], status_code=status.HTTP_200_OK)
def delete_lead_status(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], ls_id: int, db: Session = Depends(get_db)):
    try:
        deleted = LSService.delete_lead_status(db, ls_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Lead status not found"), "Deleting Lead Status failed", 404)
        return Response(json_data=deleted, message="Lead status deleted successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Deleting Lead Status failed", getattr(e, "status_code", 500))