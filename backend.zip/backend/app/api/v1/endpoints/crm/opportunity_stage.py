from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.core import auth_service as AuthService
from app.core.permissions import check_permission
from app.utils.responses import Response
from app.schemas.user_management.user import UserResponse
from app.schemas.crm import opportunity_stage as OSSchema
from app.services.crm import opportunity_stage_service as OSService

router = APIRouter()

def handle_exception(e: Exception, msg: str, code: int = 500):
    return Response(
        message=f"{msg}: {str(e)}",
        status_code=code,
        json_data=None
    )

@router.post("/", response_model=OSSchema.OpportunityStageResponse, dependencies=[check_permission(2, "/opportunity-stages", "create")], status_code=status.HTTP_201_CREATED)
def create_opportunity_stage(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], data: OSSchema.OpportunityStageCreate, db: Session = Depends(get_db)):
    try:
        result = OSService.create_opportunity_stage(db, data, login_id=current_user.id)
        return Response(json_data=result, message="Opportunity stage created successfully", status_code=status.HTTP_201_CREATED)
    except Exception as e:
        return handle_exception(e, "Creating Opportunity Stage failed", getattr(e, "status_code", 500))

@router.get("/", response_model=OSSchema.OpportunityStageResponse, dependencies=[check_permission(2, "/opportunity-stages", "view")], status_code=status.HTTP_200_OK)
def list_opportunity_stages(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], db: Session = Depends(get_db), limit: int = Query(10, ge=1, le=100), page: int = Query(1, ge=1), search: Optional[str] = Query(None)):
    try:
        offset = (page - 1) * limit
        result = OSService.get_opportunity_stages(db, skip=offset, limit=limit, search=search)
        return Response(json_data=result, message="Opportunity stages fetched successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Fetching Opportunity Stages failed", getattr(e, "status_code", 500))

@router.get("/{os_id}", response_model=OSSchema.OpportunityStageResponse, dependencies=[check_permission(2, "/opportunity-stages", "view")], status_code=status.HTTP_200_OK)
def get_opportunity_stage(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], os_id: int, db: Session = Depends(get_db)):
    try:
        result = OSService.get_opportunity_stage_by_id(db, os_id)
        if not result:
            return handle_exception(Exception("Opportunity Stage not found"), "Fetching Opportunity Stage by ID failed", 404)
        return Response(json_data=result, message="Opportunity stage fetched successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Failed to fetch opportunity stage")

@router.put("/{os_id}", response_model=OSSchema.OpportunityStageResponse, dependencies=[check_permission(2, "/opportunity-stages", "edit")], status_code=status.HTTP_200_OK)
def update_opportunity_stage(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], os_id: int, data: OSSchema.OpportunityStageUpdate, db: Session = Depends(get_db)):
    try:
        updated = OSService.update_opportunity_stage(db, os_id, data, login_id=current_user.id)
        if not updated:
            return handle_exception(Exception("Opportunity Stage not found"), "Updating Opportunity Stage failed", 404)
        return Response(json_data=updated, message="Opportunity stage updated successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Opportunity stage update failed")

@router.delete("/{os_id}", response_model=OSSchema.OpportunityStageResponse, dependencies=[check_permission(2, "/opportunity-stages", "delete")], status_code=status.HTTP_200_OK)
def delete_opportunity_stage(current_user: Annotated[UserResponse, Depends(AuthService.get_current_user)], os_id: int, db: Session = Depends(get_db)):
    try:
        deleted = OSService.delete_opportunity_stage(db, os_id, login_id=current_user.id)
        if not deleted:
            return handle_exception(Exception("Opportunity stage not found"), "Deleting Opportunity Stage failed", 404)
        return Response(json_data=deleted, message="Opportunity stage deleted successfully", status_code=status.HTTP_200_OK)
    except Exception as e:
        return handle_exception(e, "Deleting Opportunity Stage failed", getattr(e, "status_code", 500))