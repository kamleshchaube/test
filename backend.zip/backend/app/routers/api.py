from fastapi import APIRouter
from app.api.v1.endpoints.user_management import user
from app.api.v1.endpoints.user_management import role
from app.api.v1.endpoints.user_management import menu
from app.api.v1.endpoints.user_management import permission
from app.api.v1.endpoints.user_management import role_permission
from app.api.v1.endpoints.user_management import user_permission
from app.api.v1.endpoints.user_management import department
from app.api.v1.endpoints.user_management import sub_department
from app.api.v1.endpoints.user_management import designation
from app.api.v1.endpoints.user_management import user_dropdown

from app.api.v1.endpoints.masters import business_vertical
from app.api.v1.endpoints.masters import region

# CRM endpoints
from app.api.v1.endpoints.crm import lead_source
from app.api.v1.endpoints.crm import lead_status
from app.api.v1.endpoints.crm import opportunity_stage
from app.api.v1.endpoints.crm import lead
from app.api.v1.endpoints.crm import opportunity

# Sales/CRM Master endpoints
from app.api.v1.endpoints.masters import job_function

# Sales Main endpoints  
from app.api.v1.endpoints.sales import company

from app.core import auth

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])

api_router.include_router(user.router, prefix="/users", tags=["Users"])
api_router.include_router(role.router, prefix="/roles", tags=["Roles"])
api_router.include_router(menu.router, prefix="/menus", tags=["Menus"])
api_router.include_router(permission.router, prefix="/permissions", tags=["Permissions"])
api_router.include_router(role_permission.router, prefix="/role_permissions", tags=["Role-Permission"])
api_router.include_router(user_permission.router, prefix="/user_permissions", tags=["User-Permission"])
api_router.include_router(department.router, prefix="/departments", tags=["Department"])
api_router.include_router(sub_department.router, prefix="/sub-departments", tags=["SubDepartment"])
api_router.include_router(designation.router, prefix="/designations", tags=["Designation"])
api_router.include_router(business_vertical.router, prefix="/business_verticals", tags=["Business-Vertical"])
api_router.include_router(region.router, prefix="/regions", tags=["Region"])
api_router.include_router(user_dropdown.router, prefix="/user_dropdowns", tags=["dropdown"])

# CRM Module Routes
api_router.include_router(lead_source.router, prefix="/lead_sources", tags=["Lead-Sources"])
api_router.include_router(lead_status.router, prefix="/lead_statuses", tags=["Lead-Statuses"])
api_router.include_router(opportunity_stage.router, prefix="/opportunity_stages", tags=["Opportunity-Stages"])
api_router.include_router(lead.router, prefix="/leads", tags=["Leads"])
api_router.include_router(opportunity.router, prefix="/opportunities", tags=["Opportunities"])

# Sales/CRM Master Module Routes
api_router.include_router(job_function.router, prefix="/job_functions", tags=["Job-Functions"])

# Sales Main Module Routes
api_router.include_router(company.router, prefix="/companies", tags=["Companies"])







# from fastapi import APIRouter
# from app.core import auth
# from app.api.v1.endpoints.user_management import (
#     user,
#     role,
#     menu,
#     permission,
#     role_permission,
#     department,
#     sub_department,
#     designation,
#     business_vertical,
#     region
# )

# api_router = APIRouter(prefix="/api/v1")

# # 🔐 Auth
# api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])

# # 👥 User Management Endpoints (Grouped)
# endpoints = [
#     (user.router, "/users", "Users"),
#     (role.router, "/roles", "Roles"),
#     (menu.router, "/menus", "Menus"),
#     (permission.router, "/permissions", "Permissions"),
#     (role_permission.router, "/role_permission", "Role-Permission"),
#     (department.router, "/department", "Department"),
#     (sub_department.router, "/sub-department", "SubDepartment"),
#     (designation.router, "/designation", "Designation"),
#     (business_vertical.router, "/business_vertical", "Business-Vertical"),
#     (region.router, "/region", "Region"),
# ]

# for router, prefix, tag in endpoints:
#     api_router.include_router(router, prefix=prefix, tags=[tag])
