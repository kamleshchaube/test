#p1.py
def draw_pattern(n):
    # Total size of the matrix
    size = 2 * n - 1  
    for i in range(size):
        for j in range(size):
            value = n - min(i, j, size - 1 - i, size - 1 - j)
            print(value, end=' ')
        print()

# Example usage:
draw_pattern(5)

















'''
5 5 5 5 5 5 5 5 5
5 4 4 4 4 4 4 4 5
5 4 3 3 3 3 3 4 5
5 4 3 2 2 2 3 4 5
5 4 3 2 1 2 3 4 5
5 4 3 2 2 2 3 4 5
5 4 3 3 3 3 3 4 5
5 4 4 4 4 4 4 4 5
5 5 5 5 5 5 5 5 5
how to can i draw using python.
'''



