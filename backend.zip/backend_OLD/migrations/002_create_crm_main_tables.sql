-- Migration script to create CRM main tables (Leads and Opportunities)

-- Companies table (if not exists - for reference)
CREATE TABLE IF NOT EXISTS mst_companies (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts table (if not exists - for reference)
CREATE TABLE IF NOT EXISTS mst_contacts (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(150),
    phone VARCHAR(20),
    company_id INTEGER REFERENCES mst_companies(id),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Leads table
CREATE TABLE IF NOT EXISTS crm_leads (
    id SERIAL PRIMARY KEY,
    project_title VARCHAR(255) NOT NULL,
    lead_source_id INTEGER REFERENCES mst_lead_sources(id) NOT NULL,
    lead_status_id INTEGER REFERENCES mst_lead_statuses(id) NOT NULL,
    
    -- Company and Customer Details
    company_id INTEGER REFERENCES mst_companies(id) NOT NULL,
    end_customer_id INTEGER REFERENCES mst_companies(id),
    end_customer_region VARCHAR(50),
    
    -- Business Details
    sub_business_type VARCHAR(100),
    products_services JSONB,
    expected_revenue DECIMAL(15, 2) NOT NULL,
    revenue_currency VARCHAR(3) DEFAULT 'INR',
    
    -- Tender Details
    tender_type VARCHAR(100),
    tender_fee DECIMAL(15, 2),
    currency VARCHAR(3) DEFAULT 'INR',
    submission_type VARCHAR(50),
    tender_authority VARCHAR(255),
    tender_for TEXT,
    
    -- EMD and BG Details
    emd_required BOOLEAN DEFAULT FALSE,
    emd_amount DECIMAL(15, 2),
    emd_currency VARCHAR(3) DEFAULT 'INR',
    bg_required BOOLEAN DEFAULT FALSE,
    bg_amount DECIMAL(15, 2),
    bg_currency VARCHAR(3) DEFAULT 'INR',
    
    -- Additional Details
    important_dates JSONB,
    clauses JSONB,
    competitors JSONB,
    documents JSONB,
    contacts JSONB,
    
    -- Lead Management
    priority VARCHAR(20) DEFAULT 'Medium',
    qualification_notes TEXT,
    lead_score INTEGER DEFAULT 0,
    convert_to_opportunity_date DATE,
    
    -- Assignment
    sales_person_id INTEGER REFERENCES tbl_users(id),
    
    -- Conversion Workflow
    ready_for_conversion BOOLEAN DEFAULT FALSE,
    conversion_requested BOOLEAN DEFAULT FALSE,
    conversion_request_date TIMESTAMP,
    conversion_requested_by INTEGER REFERENCES tbl_users(id),
    
    -- Review and Approval
    reviewed BOOLEAN DEFAULT FALSE,
    review_status VARCHAR(20) DEFAULT 'Pending',
    reviewed_by INTEGER REFERENCES tbl_users(id),
    review_date TIMESTAMP,
    review_comments TEXT,
    
    -- Conversion Tracking
    converted BOOLEAN DEFAULT FALSE,
    converted_to_opportunity_id VARCHAR(10),
    conversion_date TIMESTAMP,
    conversion_notes TEXT,
    
    -- Standard fields
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Opportunities table
CREATE TABLE IF NOT EXISTS crm_opportunities (
    id SERIAL PRIMARY KEY,
    pot_id VARCHAR(10) UNIQUE NOT NULL,
    lead_id INTEGER REFERENCES crm_leads(id),
    company_id INTEGER REFERENCES mst_companies(id) NOT NULL,
    contact_id INTEGER REFERENCES mst_contacts(id) NOT NULL,
    
    -- Core fields
    name VARCHAR(255) NOT NULL,
    stage_id INTEGER REFERENCES mst_opportunity_stages(id) NOT NULL,
    amount DECIMAL(15, 2),
    scoring INTEGER DEFAULT 0 CHECK (scoring >= 0 AND scoring <= 100),
    bom_id INTEGER,
    costing DECIMAL(15, 2),
    status VARCHAR(20) DEFAULT 'Open',
    justification TEXT,
    close_date DATE,
    probability INTEGER DEFAULT 10 CHECK (probability >= 0 AND probability <= 100),
    notes TEXT,
    
    -- L1 - Qualification Stage Fields
    requirement_gathering_notes TEXT,
    go_no_go_status VARCHAR(20) DEFAULT 'Pending',
    qualification_completed_by INTEGER REFERENCES tbl_users(id),
    qualification_status VARCHAR(20),
    qualification_scorecard JSONB,
    
    -- L2 - Need Analysis / Demo Stage Fields
    demo_completed BOOLEAN DEFAULT FALSE,
    demo_date TIMESTAMP,
    demo_summary TEXT,
    presentation_materials JSONB,
    qualification_meeting_completed BOOLEAN DEFAULT FALSE,
    qualification_meeting_date TIMESTAMP,
    qualification_meeting_notes TEXT,
    
    -- L3 - Proposal / Bid Submission Stage Fields
    quotation_created BOOLEAN DEFAULT FALSE,
    quotation_status VARCHAR(20) DEFAULT 'Draft',
    quotation_file_path VARCHAR(500),
    quotation_version INTEGER DEFAULT 1,
    proposal_prepared BOOLEAN DEFAULT FALSE,
    proposal_file_path VARCHAR(500),
    proposal_submitted BOOLEAN DEFAULT FALSE,
    proposal_submission_date TIMESTAMP,
    poc_completed BOOLEAN DEFAULT FALSE,
    poc_notes TEXT,
    solutions_team_approval_notes TEXT,
    
    -- L4 - Negotiation Stage Fields
    customer_discussion_notes TEXT,
    proposal_updated BOOLEAN DEFAULT FALSE,
    updated_proposal_file_path VARCHAR(500),
    updated_proposal_submitted BOOLEAN DEFAULT FALSE,
    negotiated_quotation_file_path VARCHAR(500),
    negotiation_rounds INTEGER DEFAULT 0,
    commercial_approval_required BOOLEAN DEFAULT FALSE,
    commercial_approval_status VARCHAR(50),
    
    -- L5 - Won Stage Fields
    kickoff_meeting_scheduled BOOLEAN DEFAULT FALSE,
    kickoff_meeting_date TIMESTAMP,
    loi_received BOOLEAN DEFAULT FALSE,
    loi_file_path VARCHAR(500),
    order_verified BOOLEAN DEFAULT FALSE,
    handoff_to_delivery BOOLEAN DEFAULT FALSE,
    delivery_team_assigned INTEGER REFERENCES tbl_users(id),
    
    -- Lost/Dropped Stage Fields
    lost_reason VARCHAR(255),
    competitor_name VARCHAR(255),
    follow_up_date DATE,
    drop_reason VARCHAR(255),
    reactivate_date DATE,
    
    -- Standard fields
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT check_amount_positive CHECK (amount >= 0),
    CONSTRAINT check_costing_positive CHECK (costing >= 0),
    CONSTRAINT check_amount_justification CHECK (
        (amount < 1000000 AND justification IS NULL) OR 
        (amount >= 1000000 AND justification IS NOT NULL AND length(trim(justification)) > 0)
    )
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_project_title ON crm_leads(project_title);
CREATE INDEX IF NOT EXISTS idx_leads_source_status ON crm_leads(lead_source_id, lead_status_id);
CREATE INDEX IF NOT EXISTS idx_leads_company ON crm_leads(company_id);
CREATE INDEX IF NOT EXISTS idx_leads_sales_person ON crm_leads(sales_person_id);
CREATE INDEX IF NOT EXISTS idx_leads_active ON crm_leads(is_active, is_deleted);
CREATE INDEX IF NOT EXISTS idx_leads_converted ON crm_leads(converted);
CREATE INDEX IF NOT EXISTS idx_leads_conversion_requested ON crm_leads(conversion_requested);

CREATE INDEX IF NOT EXISTS idx_opportunities_pot_id ON crm_opportunities(pot_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_name ON crm_opportunities(name);
CREATE INDEX IF NOT EXISTS idx_opportunities_stage_status ON crm_opportunities(stage_id, status);
CREATE INDEX IF NOT EXISTS idx_opportunities_company ON crm_opportunities(company_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_lead ON crm_opportunities(lead_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_active ON crm_opportunities(is_active, is_deleted);
CREATE INDEX IF NOT EXISTS idx_opportunities_close_date ON crm_opportunities(close_date);

-- Create function to auto-generate POT ID
CREATE OR REPLACE FUNCTION generate_pot_id()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.pot_id IS NULL OR NEW.pot_id = '' THEN
        NEW.pot_id := 'POT-' || LPAD((FLOOR(RANDOM() * 9000) + 1000)::TEXT, 4, '0');
        -- Ensure uniqueness
        WHILE EXISTS (SELECT 1 FROM crm_opportunities WHERE pot_id = NEW.pot_id) LOOP
            NEW.pot_id := 'POT-' || LPAD((FLOOR(RANDOM() * 9000) + 1000)::TEXT, 4, '0');
        END LOOP;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for auto-generating POT ID
CREATE TRIGGER trigger_generate_pot_id
    BEFORE INSERT ON crm_opportunities
    FOR EACH ROW
    EXECUTE FUNCTION generate_pot_id();