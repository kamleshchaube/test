-- Migration script to create Sales module master tables

-- Job Functions Master Table
CREATE TABLE IF NOT EXISTS mst_job_functions (
    id SERIAL PRIMARY KEY,
    job_function_name VARCHAR(150) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Partner Types Master Table
CREATE TABLE IF NOT EXISTS mst_partner_types (
    id SERIAL PRIMARY KEY,
    partner_type_name VARCHAR(150) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Company Types Master Table (update existing if needed)
CREATE TABLE IF NOT EXISTS mst_company_types (
    id SERIAL PRIMARY KEY,
    type_name VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Account Types Master Table
CREATE TABLE IF NOT EXISTS mst_account_types (
    id SERIAL PRIMARY KEY,
    account_type_name VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Business Types Master Table
CREATE TABLE IF NOT EXISTS mst_business_types (
    id SERIAL PRIMARY KEY,
    business_type_name VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Industry Segments Master Table
CREATE TABLE IF NOT EXISTS mst_industry_segments (
    id SERIAL PRIMARY KEY,
    industry_name VARCHAR(150) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sub Industry Segments Master Table
CREATE TABLE IF NOT EXISTS mst_sub_industry_segments (
    id SERIAL PRIMARY KEY,
    industry_id INTEGER REFERENCES mst_industry_segments(id) NOT NULL,
    sub_industry_name VARCHAR(150) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Address Types Master Table
CREATE TABLE IF NOT EXISTS mst_address_types (
    id SERIAL PRIMARY KEY,
    address_type_name VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Countries Master Table
CREATE TABLE IF NOT EXISTS mst_countries (
    id SERIAL PRIMARY KEY,
    country_name VARCHAR(100) UNIQUE NOT NULL,
    country_code VARCHAR(10) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- States Master Table
CREATE TABLE IF NOT EXISTS mst_states (
    id SERIAL PRIMARY KEY,
    country_id INTEGER REFERENCES mst_countries(id) NOT NULL,
    state_name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cities Master Table
CREATE TABLE IF NOT EXISTS mst_cities (
    id SERIAL PRIMARY KEY,
    state_id INTEGER REFERENCES mst_states(id) NOT NULL,
    city_name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Document Types Master Table
CREATE TABLE IF NOT EXISTS mst_document_types (
    id SERIAL PRIMARY KEY,
    document_type_name VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Currencies Master Table
CREATE TABLE IF NOT EXISTS mst_currencies (
    id SERIAL PRIMARY KEY,
    currency_code VARCHAR(10) UNIQUE NOT NULL,
    currency_name VARCHAR(50) NOT NULL,
    symbol VARCHAR(10),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Head of Company Master Table
CREATE TABLE IF NOT EXISTS mst_head_of_companies (
    id SERIAL PRIMARY KEY,
    head_role_name VARCHAR(150) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product Services Master Table
CREATE TABLE IF NOT EXISTS mst_product_services (
    id SERIAL PRIMARY KEY,
    product_service_name VARCHAR(255) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default data for master tables
INSERT INTO mst_job_functions (job_function_name) VALUES
('Sales'),
('Marketing'),
('Finance'),
('Operations'),
('Human Resources'),
('IT'),
('Customer Support');

INSERT INTO mst_partner_types (partner_type_name) VALUES
('Distributor'),
('OEM'),
('Reseller'),
('System Integrator'),
('Consultant');

INSERT INTO mst_company_types (type_name) VALUES
('Private Limited'),
('Public Limited'),
('Partnership'),
('Sole Proprietorship'),
('Government'),
('NGO'),
('LLP');

INSERT INTO mst_account_types (account_type_name) VALUES
('Customer'),
('Partner'),
('Prospect'),
('Vendor'),
('Competitor');

INSERT INTO mst_business_types (business_type_name) VALUES
('Direct'),
('Channel'),
('Online'),
('Retail'),
('Enterprise');

INSERT INTO mst_industry_segments (industry_name) VALUES
('IT'),
('BFSI'),
('Healthcare'),
('Education'),
('Manufacturing'),
('Retail'),
('Government'),
('Telecommunications');

INSERT INTO mst_address_types (address_type_name) VALUES
('Registered'),
('Billing'),
('Communication'),
('Warehouse'),
('Branch Office');

INSERT INTO mst_countries (country_name, country_code) VALUES
('India', 'IN'),
('United States', 'US'),
('United Kingdom', 'GB'),
('Singapore', 'SG'),
('Australia', 'AU');

INSERT INTO mst_document_types (document_type_name) VALUES
('GST Certificate'),
('PAN Card'),
('Incorporation Certificate'),
('Bank Statement'),
('Audited Financials'),
('ISO Certificate');

INSERT INTO mst_currencies (currency_code, currency_name, symbol) VALUES
('INR', 'Indian Rupee', '₹'),
('USD', 'US Dollar', '$'),
('EUR', 'Euro', '€'),
('GBP', 'British Pound', '£'),
('SGD', 'Singapore Dollar', 'S$');

INSERT INTO mst_head_of_companies (head_role_name) VALUES
('CEO'),
('MD'),
('Director'),
('Chairman'),
('President'),
('Vice President'),
('General Manager'),
('Manager');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_job_functions_name ON mst_job_functions(job_function_name);
CREATE INDEX IF NOT EXISTS idx_job_functions_active ON mst_job_functions(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_company_types_name ON mst_company_types(type_name);
CREATE INDEX IF NOT EXISTS idx_company_types_active ON mst_company_types(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_countries_name ON mst_countries(country_name);
CREATE INDEX IF NOT EXISTS idx_countries_code ON mst_countries(country_code);
CREATE INDEX IF NOT EXISTS idx_countries_active ON mst_countries(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_states_country ON mst_states(country_id);
CREATE INDEX IF NOT EXISTS idx_states_name ON mst_states(state_name);
CREATE INDEX IF NOT EXISTS idx_states_active ON mst_states(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_cities_state ON mst_cities(state_id);
CREATE INDEX IF NOT EXISTS idx_cities_name ON mst_cities(city_name);
CREATE INDEX IF NOT EXISTS idx_cities_active ON mst_cities(is_active, is_deleted);