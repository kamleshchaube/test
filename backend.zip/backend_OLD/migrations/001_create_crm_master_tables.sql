-- Migration script to create CRM master tables
-- Lead Sources Master Table
CREATE TABLE IF NOT EXISTS mst_lead_sources (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lead Statuses Master Table
CREATE TABLE IF NOT EXISTS mst_lead_statuses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Opportunity Stages Master Table
CREATE TABLE IF NOT EXISTS mst_opportunity_stages (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    percentage INTEGER DEFAULT 0 CHECK (percentage >= 0 AND percentage <= 100),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default Lead Sources
INSERT INTO mst_lead_sources (name, description) VALUES
('Direct Marketing', 'Direct marketing campaigns and outreach'),
('Referral', 'Customer and partner referrals'),
('Advertisement', 'Online and offline advertisements'),
('Event', 'Trade shows, conferences, and events'),
('Website', 'Website inquiries and contact forms'),
('Cold Call', 'Cold calling campaigns'),
('Social Media', 'Social media platforms and campaigns'),
('Other', 'Other lead sources');

-- Insert default Lead Statuses
INSERT INTO mst_lead_statuses (name, description) VALUES
('New', 'Newly created lead'),
('Active', 'Lead is being actively pursued'),
('Contacted', 'Initial contact has been made'),
('Qualified', 'Lead has been qualified and meets criteria'),
('Unqualified', 'Lead does not meet qualification criteria'),
('Converted', 'Lead has been converted to opportunity'),
('Rejected', 'Lead has been rejected or declined');

-- Insert default Opportunity Stages
INSERT INTO mst_opportunity_stages (name, description, percentage) VALUES
('L1_Prospect', 'Initial prospect identification', 5),
('L1_Qualification', 'Lead qualification phase', 15),
('L2_Need_Analysis', 'Need analysis and demo phase', 40),
('L3_Proposal', 'Proposal and bid submission', 60),
('L4_Negotiation', 'Negotiation and final discussions', 80),
('L5_Won', 'Opportunity won', 100),
('L6_Lost', 'Opportunity lost to competitor', 0),
('L7_Dropped', 'Opportunity dropped or cancelled', 0);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_lead_sources_name ON mst_lead_sources(name);
CREATE INDEX IF NOT EXISTS idx_lead_sources_active ON mst_lead_sources(is_active, is_deleted);
CREATE INDEX IF NOT EXISTS idx_lead_statuses_name ON mst_lead_statuses(name);
CREATE INDEX IF NOT EXISTS idx_lead_statuses_active ON mst_lead_statuses(is_active, is_deleted);
CREATE INDEX IF NOT EXISTS idx_opportunity_stages_name ON mst_opportunity_stages(name);
CREATE INDEX IF NOT EXISTS idx_opportunity_stages_active ON mst_opportunity_stages(is_active, is_deleted);