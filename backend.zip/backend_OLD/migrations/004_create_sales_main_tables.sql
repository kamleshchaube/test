-- Migration script to create Sales module main tables

-- Partners table
CREATE TABLE IF NOT EXISTS partners (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150),
    email VARCHAR(200) UNIQUE NOT NULL,
    phone VARCHAR(20),
    job_function_id INTEGER REFERENCES mst_job_functions(id),
    
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Companies table (main company master)
CREATE TABLE IF NOT EXISTS companies (
    id SERIAL PRIMARY KEY,
    company_code VARCHAR(100) UNIQUE NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    company_type_id INTEGER REFERENCES mst_company_types(id),
    gst_no VARCHAR(50) NOT NULL,
    pan_no VARCHAR(50) NOT NULL,
    account_type_id INTEGER REFERENCES mst_account_types(id),
    account_region_id INTEGER REFERENCES mst_regions(id),  -- References existing regions table
    business_type_id INTEGER REFERENCES mst_business_types(id),
    industry_segment_id INTEGER REFERENCES mst_industry_segments(id),
    sub_industry_segment_id INTEGER REFERENCES mst_sub_industry_segments(id),
    partner_type_id INTEGER REFERENCES mst_partner_types(id),
    head_of_company_id INTEGER REFERENCES mst_head_of_companies(id),
    website VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_child BOOLEAN DEFAULT FALSE,
    remarks TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,
    
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT unique_gst_not_deleted CHECK (
        (is_deleted = TRUE) OR 
        (is_deleted = FALSE AND gst_no IS NOT NULL)
    ),
    CONSTRAINT unique_pan_not_deleted CHECK (
        (is_deleted = TRUE) OR 
        (is_deleted = FALSE AND pan_no IS NOT NULL)
    )
);

-- Company Addresses table
CREATE TABLE IF NOT EXISTS company_addresses (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES companies(id) NOT NULL,
    address_type_id INTEGER REFERENCES mst_address_types(id) NOT NULL,
    address TEXT NOT NULL,
    country_id INTEGER REFERENCES mst_countries(id) NOT NULL,
    state_id INTEGER REFERENCES mst_states(id) NOT NULL,
    city_id INTEGER REFERENCES mst_cities(id) NOT NULL,
    zipcode VARCHAR(20),
    
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Company Documents table
CREATE TABLE IF NOT EXISTS company_documents (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES companies(id) NOT NULL,
    document_type_id INTEGER REFERENCES mst_document_types(id) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    description TEXT,
    
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Company Financials table
CREATE TABLE IF NOT EXISTS company_financials (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES companies(id) NOT NULL,
    year VARCHAR(4) NOT NULL,
    revenue DECIMAL(18,2),
    profit DECIMAL(18,2),
    currency_id INTEGER REFERENCES mst_currencies(id) NOT NULL,
    type VARCHAR(20) CHECK (type IN ('turnover', 'profit', 'revenue')) NOT NULL,
    
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Unique constraint for company, year, type combination
    UNIQUE(company_id, year, type)
);

-- Contacts table
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES companies(id) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(20),
    mobile VARCHAR(20),
    designation_id INTEGER REFERENCES mst_head_of_companies(id),
    department VARCHAR(100),
    is_primary BOOLEAN DEFAULT FALSE,
    
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES tbl_users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);
CREATE INDEX IF NOT EXISTS idx_partners_job_function ON partners(job_function_id);
CREATE INDEX IF NOT EXISTS idx_partners_active ON partners(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_companies_code ON companies(company_code);
CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(company_name);
CREATE INDEX IF NOT EXISTS idx_companies_gst ON companies(gst_no);
CREATE INDEX IF NOT EXISTS idx_companies_pan ON companies(pan_no);
CREATE INDEX IF NOT EXISTS idx_companies_type ON companies(company_type_id);
CREATE INDEX IF NOT EXISTS idx_companies_industry ON companies(industry_segment_id);
CREATE INDEX IF NOT EXISTS idx_companies_active ON companies(is_active, is_deleted);

CREATE INDEX IF NOT EXISTS idx_company_addresses_company ON company_addresses(company_id);
CREATE INDEX IF NOT EXISTS idx_company_addresses_type ON company_addresses(address_type_id);
CREATE INDEX IF NOT EXISTS idx_company_addresses_location ON company_addresses(country_id, state_id, city_id);

CREATE INDEX IF NOT EXISTS idx_company_documents_company ON company_documents(company_id);
CREATE INDEX IF NOT EXISTS idx_company_documents_type ON company_documents(document_type_id);

CREATE INDEX IF NOT EXISTS idx_company_financials_company ON company_financials(company_id);
CREATE INDEX IF NOT EXISTS idx_company_financials_year ON company_financials(year);

CREATE INDEX IF NOT EXISTS idx_contacts_company ON contacts(company_id);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_primary ON contacts(is_primary);
CREATE INDEX IF NOT EXISTS idx_contacts_active ON contacts(is_active, is_deleted);

-- Add some constraints and triggers for data integrity
-- Ensure only one primary contact per company
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_primary_contact 
ON contacts(company_id) 
WHERE is_primary = TRUE AND is_deleted = FALSE;

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add triggers for updated_at columns
CREATE TRIGGER update_partners_updated_at BEFORE UPDATE ON partners 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_company_addresses_updated_at BEFORE UPDATE ON company_addresses 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_company_documents_updated_at BEFORE UPDATE ON company_documents 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_company_financials_updated_at BEFORE UPDATE ON company_financials 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON contacts 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();