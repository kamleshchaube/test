# sales/__init__.py
from .contact import Contact 

__all__ = ["Contact"]
