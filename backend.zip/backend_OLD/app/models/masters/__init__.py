# models/__init__.py
from .business_vertical import BusinessVertical 
from .region import Region 

__all__ = ["BusinessVertical", "Region"]
